#!/usr/bin/env python3
"""
Autoaperfeiçoamento seguro — Jarvis 1.0
=======================================
O Jarvis pode:
1. Registrar erros e feedback seu ("isso está errado", "melhora X")
2. Analisar histórico e propor melhorias
3. Aplicar só mudanças SEGURAS (com confirmação):
   - correções de STT
   - preferências / estilo de resposta
   - fatos e orientações
   - plugins novos em plugins/
   - arquivos de conhecimento JSON
4. NUNCA reescreve jarvis.py sozinho.
   Propostas de código do núcleo vão para propostas/ para você revisar.
"""

from __future__ import annotations

import os
import re
import json
import time
import datetime
import subprocess
import hashlib
from pathlib import Path
from typing import Optional, Callable, Any

_SCRIPT_DIR = Path(__file__).resolve().parent
if (_SCRIPT_DIR / "jarvis.py").exists() or (_SCRIPT_DIR / "memory").exists():
    BASE_DIR = _SCRIPT_DIR
else:
    BASE_DIR = Path.home() / "Jarvis"

MEMORY_DIR = BASE_DIR / "memory"
PLUGIN_DIR = BASE_DIR / "plugins"
KNOWLEDGE_DIR = BASE_DIR / "conhecimento"
PROPOSTAS_DIR = BASE_DIR / "propostas"

FEEDBACK_FILE = MEMORY_DIR / "feedback_melhorias.json"
PROPOSTAS_FILE = MEMORY_DIR / "propostas_pendentes.json"
HISTORICO_AUTO_FILE = MEMORY_DIR / "autoaperfeicoar_log.json"

DEFAULT_MODEL = os.environ.get("JARVIS_MODEL", "qwen2.5:7b")

_falar: Optional[Callable] = None
_console = None
_carregar_memoria: Optional[Callable] = None
_salvar_memoria: Optional[Callable] = None
_salvar_correcao_stt: Optional[Callable] = None
_salvar_preferencia: Optional[Callable] = None
_adicionar_fato: Optional[Callable] = None
_adicionar_aprendizado: Optional[Callable] = None

# tipos que podem ser aplicados automaticamente (após "confirmar melhoria")
TIPOS_SEGUROS = {
    "correcao_stt",
    "preferencia",
    "fato",
    "aprendizado",
    "orientacao",
    "plugin",
    "conhecimento_json",
}

# tipos que só geram arquivo para revisão humana
TIPOS_CODIGO = {
    "codigo_nucleo",
    "patch_jarvis",
    "refactor",
}


def configurar(
    falar_fn=None,
    console=None,
    carregar_memoria=None,
    salvar_memoria=None,
    salvar_correcao_stt=None,
    salvar_preferencia=None,
    adicionar_fato=None,
    adicionar_aprendizado=None,
):
    global _falar, _console, _carregar_memoria, _salvar_memoria
    global _salvar_correcao_stt, _salvar_preferencia, _adicionar_fato, _adicionar_aprendizado
    _falar = falar_fn
    _console = console
    _carregar_memoria = carregar_memoria
    _salvar_memoria = salvar_memoria
    _salvar_correcao_stt = salvar_correcao_stt
    _salvar_preferencia = salvar_preferencia
    _adicionar_fato = adicionar_fato
    _adicionar_aprendizado = adicionar_aprendizado
    for d in (MEMORY_DIR, PLUGIN_DIR, KNOWLEDGE_DIR, PROPOSTAS_DIR):
        d.mkdir(parents=True, exist_ok=True)


def _log(msg: str):
    if _console:
        try:
            _console.print(f"[dim]Auto:[/] {msg}")
            return
        except Exception:
            pass
    print(f"[Auto] {msg}")


def _load_json(path: Path, default):
    if path.exists():
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            pass
    return default


def _save_json(path: Path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)


def _append_log(evento: str, detalhe: str = ""):
    log = _load_json(HISTORICO_AUTO_FILE, {"eventos": []})
    log.setdefault("eventos", []).append({
        "evento": evento,
        "detalhe": detalhe[:500],
        "data": datetime.datetime.now().isoformat(),
    })
    log["eventos"] = log["eventos"][-200:]
    _save_json(HISTORICO_AUTO_FILE, log)


# ------------------------------------------------------------
# Feedback do usuário
# ------------------------------------------------------------

def registrar_feedback(texto: str, tipo: str = "geral", contexto: str = "") -> str:
    """Registra reclamação, correção ou pedido de melhoria."""
    data = _load_json(FEEDBACK_FILE, {"itens": []})
    item = {
        "id": hashlib.md5(f"{time.time()}{texto}".encode()).hexdigest()[:10],
        "tipo": tipo,
        "texto": texto.strip()[:800],
        "contexto": (contexto or "")[:400],
        "data": datetime.datetime.now().isoformat(),
        "status": "pendente",
    }
    data.setdefault("itens", []).append(item)
    data["itens"] = data["itens"][-150:]
    _save_json(FEEDBACK_FILE, data)
    _append_log("feedback", f"{tipo}: {texto[:120]}")
    return (
        f"Anotei esse feedback ({item['id']}). "
        "Diga 'se auto aprimore' para eu analisar e propor melhorias, "
        "ou 'aplicar melhoria' depois de eu propor."
    )


def listar_feedback(n: int = 8) -> str:
    data = _load_json(FEEDBACK_FILE, {"itens": []})
    itens = data.get("itens", [])[-n:]
    if not itens:
        return "Ainda não há feedback registrado. Diga por exemplo: isso está errado, você deveria responder mais curto."
    linhas = []
    for it in itens:
        st = it.get("status", "?")
        linhas.append(f"- [{it.get('id')}] ({st}) {it.get('tipo')}: {it.get('texto', '')[:100]}")
    return "Feedback recente:\n" + "\n".join(linhas)


# ------------------------------------------------------------
# Propostas
# ------------------------------------------------------------

def _propostas_pendentes() -> list:
    data = _load_json(PROPOSTAS_FILE, {"propostas": []})
    return [p for p in data.get("propostas", []) if p.get("status") == "pendente"]


def _salvar_propostas_all(propostas: list):
    _save_json(PROPOSTAS_FILE, {"propostas": propostas[-50:], "atualizado_em": datetime.datetime.now().isoformat()})


def listar_propostas() -> str:
    data = _load_json(PROPOSTAS_FILE, {"propostas": []})
    props = data.get("propostas", [])[-10:]
    if not props:
        return "Nenhuma proposta ainda. Diga: se auto aprimore."
    linhas = []
    for p in props:
        linhas.append(
            f"- [{p.get('id')}] ({p.get('status')}) {p.get('tipo')}: {p.get('titulo', '')[:80]}"
        )
    pend = sum(1 for p in props if p.get("status") == "pendente")
    extra = f"\n{pend} pendente(s). Diga 'aplicar melhoria' ou 'aplicar melhoria ID'."
    return "Propostas de melhoria:\n" + "\n".join(linhas) + extra


def _chamar_ollama(prompt: str, timeout: int = 90) -> str:
    try:
        r = subprocess.run(
            ["ollama", "run", DEFAULT_MODEL, prompt],
            capture_output=True, text=True, timeout=timeout,
            encoding="utf-8", errors="ignore",
        )
        return (r.stdout or "").strip()
    except FileNotFoundError:
        return ""
    except Exception as e:
        _log(f"ollama: {e}")
        return ""


def _extrair_json(texto: str) -> Any:
    if not texto:
        return None
    # tenta bloco ```json
    m = re.search(r"```(?:json)?\s*([\s\S]+?)```", texto)
    bruto = m.group(1) if m else texto
    inicio, fim = bruto.find("["), bruto.rfind("]")
    if inicio >= 0 and fim > inicio:
        try:
            return json.loads(bruto[inicio:fim + 1])
        except Exception:
            pass
    inicio, fim = bruto.find("{"), bruto.rfind("}")
    if inicio >= 0 and fim > inicio:
        try:
            return json.loads(bruto[inicio:fim + 1])
        except Exception:
            pass
    return None


def _heuristica_local(feedbacks: list, historico: list) -> list:
    """Gera propostas sem Ollama, com regras simples."""
    propostas = []
    for fb in feedbacks:
        txt = (fb.get("texto") or "").lower()
        # correção STT explícita já tratada em outro fluxo; aqui sugerimos preferências
        if any(w in txt for w in ("curto", "curta", "objetivo", "direto", "resumo")):
            propostas.append({
                "tipo": "preferencia",
                "titulo": "Respostas mais curtas",
                "descricao": "Usuário pediu respostas mais diretas.",
                "payload": {"chave": "tamanho_resposta", "valor": "curto"},
            })
        if any(w in txt for w in ("educado", "formal", "respeitoso")):
            propostas.append({
                "tipo": "preferencia",
                "titulo": "Tom mais formal",
                "descricao": "Ajustar estilo de resposta.",
                "payload": {"chave": "estilo_resposta", "valor": "educado, profissional e prestativo"},
            })
        if any(w in txt for w in ("errado", "não era isso", "nao era isso", "incorreto", "errou")):
            propostas.append({
                "tipo": "aprendizado",
                "titulo": "Registrar correção do usuário",
                "descricao": fb.get("texto", "")[:200],
                "payload": {"texto": f"Correção do usuário: {fb.get('texto', '')[:200]}"},
            })
        if "plugin" in txt or "comando novo" in txt:
            propostas.append({
                "tipo": "plugin",
                "titulo": "Esboço de plugin pedido pelo usuário",
                "descricao": fb.get("texto", "")[:200],
                "payload": {
                    "nome": "plugin_pedido_usuario",
                    "codigo": _template_plugin("pedido_usuario", fb.get("texto", "")[:120]),
                },
            })
    # se histórico mostra muitas correções STT manuais, só informa
    if not propostas and feedbacks:
        propostas.append({
            "tipo": "fato",
            "titulo": "Lembrar feedback recente",
            "descricao": feedbacks[-1].get("texto", "")[:200],
            "payload": {"texto": f"Feedback do usuário: {feedbacks[-1].get('texto', '')[:200]}"},
        })
    return propostas[:5]


def _template_plugin(nome: str, dica: str) -> str:
    safe = re.sub(r"[^a-z0-9_]", "_", nome.lower())[:30] or "custom"
    return f'''"""Plugin gerado pelo autoaperfeiçoamento do Jarvis."""

def processar(texto):
    t = (texto or "").strip().lower()
    # Dica original do usuário: {dica!r}
    if t in ("teste {safe}", "rodar {safe}"):
        return "Plugin {safe} ativo."
    return None
'''


def gerar_propostas(motivo: str = "") -> str:
    """Analisa feedback + histórico e cria propostas pendentes."""
    fb_data = _load_json(FEEDBACK_FILE, {"itens": []})
    feedbacks = [x for x in fb_data.get("itens", []) if x.get("status") == "pendente"][-12:]
    historico = []
    if _carregar_memoria:
        try:
            mem = _carregar_memoria() or {}
            historico = mem.get("historico", [])[-15:]
        except Exception:
            pass

    if not feedbacks and not motivo and not historico:
        return (
            "Não tenho feedback nem histórico suficiente. "
            "Primeiro diga o que posso melhorar, por exemplo: "
            "'isso está errado, responda mais curto' ou 'quando eu disser X, entenda Y'."
        )

    prompt = f"""Você ajuda o assistente Jarvis a se melhorar com segurança.
Com base no feedback e histórico, proponha 1 a 5 melhorias.
Responda APENAS um JSON array. Cada item:
{{
  "tipo": "correcao_stt|preferencia|fato|aprendizado|orientacao|plugin|conhecimento_json|codigo_nucleo",
  "titulo": "curto",
  "descricao": "por que",
  "payload": {{}}
}}

Regras de payload:
- correcao_stt: {{"errado":"...","correto":"..."}}
- preferencia: {{"chave":"tamanho_resposta|estilo_resposta|interesses","valor":"..."}}
- fato|aprendizado|orientacao: {{"texto":"..."}}
- plugin: {{"nome":"snake_case","codigo":"python com def processar(texto):..."}}
- conhecimento_json: {{"titulo":"...","conteudo":"..."}}
- codigo_nucleo: {{"arquivo":"jarvis.py","ideia":"...","pseudocodigo":"..."}}
  (codigo_nucleo NÃO é aplicado sozinho; só vira arquivo em propostas/)

Feedbacks:
{json.dumps(feedbacks, ensure_ascii=False)[:2500]}

Últimos turnos:
{json.dumps(historico, ensure_ascii=False)[:2500]}

Motivo extra do usuário: {motivo or "(nenhum)"}
"""

    bruto = _chamar_ollama(prompt)
    parsed = _extrair_json(bruto)
    if isinstance(parsed, dict):
        parsed = parsed.get("propostas") or parsed.get("items") or [parsed]
    if not isinstance(parsed, list) or not parsed:
        parsed = _heuristica_local(feedbacks, historico)

    existentes = _load_json(PROPOSTAS_FILE, {"propostas": []}).get("propostas", [])
    novas = []
    for raw in parsed[:5]:
        if not isinstance(raw, dict):
            continue
        tipo = str(raw.get("tipo", "fato")).strip().lower()
        if tipo not in TIPOS_SEGUROS and tipo not in TIPOS_CODIGO:
            tipo = "fato"
        pid = hashlib.md5(f"{time.time()}{tipo}{raw.get('titulo')}".encode()).hexdigest()[:10]
        prop = {
            "id": pid,
            "tipo": tipo,
            "titulo": str(raw.get("titulo") or tipo)[:120],
            "descricao": str(raw.get("descricao") or "")[:400],
            "payload": raw.get("payload") if isinstance(raw.get("payload"), dict) else {},
            "status": "pendente",
            "criado_em": datetime.datetime.now().isoformat(),
            "seguro": tipo in TIPOS_SEGUROS,
        }
        # propostas de código → arquivo legível
        if tipo in TIPOS_CODIGO:
            arq = PROPOSTAS_DIR / f"proposta_{pid}.md"
            arq.write_text(
                f"# Proposta {pid}\n\n**Título:** {prop['titulo']}\n\n"
                f"**Descrição:** {prop['descricao']}\n\n"
                f"```json\n{json.dumps(prop['payload'], ensure_ascii=False, indent=2)}\n```\n\n"
                f"_Esta proposta NÃO altera o código sozinha. Revise e edite manualmente se concordar._\n",
                encoding="utf-8",
            )
            prop["arquivo_proposta"] = str(arq)
        existentes.append(prop)
        novas.append(prop)

    # marca feedbacks como analisados
    for fb in fb_data.get("itens", []):
        if fb.get("status") == "pendente":
            fb["status"] = "analisado"
    _save_json(FEEDBACK_FILE, fb_data)
    _salvar_propostas_all(existentes)
    _append_log("propostas_geradas", f"{len(novas)} novas")

    if not novas:
        return "Analisei, mas não encontrei melhorias concretas. Descreva o problema com mais detalhe."

    linhas = [f"Gerei {len(novas)} proposta(s):"]
    for p in novas:
        tag = "segura" if p.get("seguro") else "só revisão (código)"
        linhas.append(f"- [{p['id']}] ({tag}) {p['tipo']}: {p['titulo']}")
        if p.get("descricao"):
            linhas.append(f"  → {p['descricao'][:120]}")
    linhas.append("Para aplicar as seguras: diga 'aplicar melhoria' ou 'aplicar melhoria ID'.")
    linhas.append("Código do núcleo nunca é alterado sozinho — fica em propostas/.")
    return "\n".join(linhas)


def _aplicar_uma(prop: dict) -> str:
    tipo = prop.get("tipo")
    payload = prop.get("payload") or {}

    if tipo in TIPOS_CODIGO:
        prop["status"] = "somente_revisao"
        return (
            f"Proposta [{prop.get('id')}] é de código do núcleo — "
            f"não aplico sozinho. Arquivo: {prop.get('arquivo_proposta', 'propostas/')}"
        )

    if tipo == "correcao_stt":
        errado = str(payload.get("errado") or payload.get("de") or "").strip()
        correto = str(payload.get("correto") or payload.get("para") or "").strip()
        if not errado or not correto:
            return f"[{prop.get('id')}] correção STT incompleta."
        if _salvar_correcao_stt:
            msg = _salvar_correcao_stt(errado, correto)
        else:
            msg = f"STT: '{errado}' → '{correto}' (handler ausente)"
        prop["status"] = "aplicada"
        return f"[{prop.get('id')}] {msg}"

    if tipo == "preferencia":
        chave = str(payload.get("chave") or "").strip()
        valor = str(payload.get("valor") or "").strip()
        if not chave or not valor:
            return f"[{prop.get('id')}] preferência incompleta."
        if _salvar_preferencia:
            _salvar_preferencia(chave, valor)
        prop["status"] = "aplicada"
        return f"[{prop.get('id')}] Preferência salva: {chave} = {valor}"

    if tipo in ("fato", "aprendizado", "orientacao"):
        texto = str(payload.get("texto") or prop.get("descricao") or "").strip()
        if not texto:
            return f"[{prop.get('id')}] texto vazio."
        if tipo == "fato" and _adicionar_fato:
            _adicionar_fato(texto, fonte="autoaperfeicoar")
        elif tipo == "aprendizado" and _adicionar_aprendizado:
            _adicionar_aprendizado(texto)
        elif tipo == "orientacao" and _salvar_preferencia:
            ant = ""
            if _carregar_memoria:
                try:
                    ant = (_carregar_memoria() or {}).get("preferencias", {}).get("orientacoes_personalizadas", "")
                except Exception:
                    pass
            novo = (ant + " | " if ant else "") + texto
            _salvar_preferencia("orientacoes_personalizadas", novo[:500])
        else:
            if _adicionar_aprendizado:
                _adicionar_aprendizado(texto)
        prop["status"] = "aplicada"
        return f"[{prop.get('id')}] Registrado ({tipo})."

    if tipo == "plugin":
        nome = str(payload.get("nome") or "plugin_auto").strip()
        nome = re.sub(r"[^A-Za-z0-9_]", "_", nome)[:40] or "plugin_auto"
        codigo = payload.get("codigo") or _template_plugin(nome, prop.get("titulo", ""))
        # segurança mínima: só permite def processar
        if "def processar" not in codigo:
            return f"[{prop.get('id')}] plugin sem def processar — ignorado."
        if any(x in codigo for x in ("os.system", "subprocess", "socket", "eval(", "exec(", "__import__")):
            return f"[{prop.get('id')}] plugin bloqueado (operações sensíveis)."
        caminho = PLUGIN_DIR / f"{nome}.py"
        caminho.write_text(codigo, encoding="utf-8")
        # ativa no ativos.json
        cfg_path = PLUGIN_DIR / "ativos.json"
        cfg = _load_json(cfg_path, {"ativos": []})
        ativos = cfg.get("ativos") if isinstance(cfg.get("ativos"), list) else []
        if nome not in ativos:
            ativos.append(nome)
        cfg["ativos"] = ativos
        _save_json(cfg_path, cfg)
        prop["status"] = "aplicada"
        return f"[{prop.get('id')}] Plugin '{nome}' criado. Reinicie ou recarregue plugins para usar."

    if tipo == "conhecimento_json":
        titulo = str(payload.get("titulo") or prop.get("titulo") or "Auto conhecimento").strip()
        conteudo = str(payload.get("conteudo") or payload.get("texto") or "").strip()
        if not conteudo:
            return f"[{prop.get('id')}] conhecimento vazio."
        safe = re.sub(r"[^\w\-]+", "_", titulo.lower())[:40]
        arq = KNOWLEDGE_DIR / f"auto_{safe}_{datetime.datetime.now().strftime('%Y%m%d')}.json"
        arq.write_text(json.dumps({
            "titulo": titulo,
            "conteudo": conteudo,
            "tags": ["autoaperfeicoar"],
            "criado_em": datetime.datetime.now().isoformat(),
        }, ensure_ascii=False, indent=2), encoding="utf-8")
        prop["status"] = "aplicada"
        return f"[{prop.get('id')}] Conhecimento salvo em {arq.name}."

    return f"[{prop.get('id')}] tipo desconhecido: {tipo}"


def aplicar_propostas(id_especifico: Optional[str] = None) -> str:
    data = _load_json(PROPOSTAS_FILE, {"propostas": []})
    props = data.get("propostas", [])
    alvos = []
    if id_especifico:
        id_especifico = id_especifico.strip().lower()
        alvos = [p for p in props if p.get("id", "").lower() == id_especifico and p.get("status") == "pendente"]
        if not alvos:
            return f"Não achei proposta pendente com id '{id_especifico}'. Diga 'listar propostas'."
    else:
        alvos = [p for p in props if p.get("status") == "pendente" and p.get("tipo") in TIPOS_SEGUROS]

    if not alvos:
        return "Nenhuma proposta segura pendente. Diga 'se auto aprimore' ou 'listar propostas'."

    resultados = []
    for p in alvos:
        try:
            resultados.append(_aplicar_uma(p))
        except Exception as e:
            resultados.append(f"[{p.get('id')}] erro: {e}")
            p["status"] = "erro"

    _salvar_propostas_all(props)
    _append_log("propostas_aplicadas", "; ".join(resultados)[:300])
    return "Resultado da aplicação:\n" + "\n".join(resultados)


def rejeitar_propostas(id_especifico: Optional[str] = None) -> str:
    data = _load_json(PROPOSTAS_FILE, {"propostas": []})
    props = data.get("propostas", [])
    n = 0
    for p in props:
        if p.get("status") != "pendente":
            continue
        if id_especifico and p.get("id", "").lower() != id_especifico.strip().lower():
            continue
        p["status"] = "rejeitada"
        n += 1
    _salvar_propostas_all(props)
    return f"Rejeitei {n} proposta(s)."


def ciclo_autoaperfeicoar(motivo: str = "") -> str:
    """Atalho: gera propostas a partir do que já sabe + motivo opcional."""
    if motivo:
        registrar_feedback(motivo, tipo="pedido_melhoria")
    return gerar_propostas(motivo=motivo)


# ------------------------------------------------------------
# Roteador de comandos
# ------------------------------------------------------------

def processar_autoaperfeicoar(texto: str) -> Optional[str]:
    if not texto:
        return None
    t = texto.lower().strip()

    # registrar feedback implícito
    if any(x in t for x in (
        "isso está errado", "isso esta errado", "você errou", "voce errou",
        "não era isso", "nao era isso", "resposta errada", "melhorar isso",
        "você deveria", "voce deveria", "da próxima vez", "da proxima vez",
    )):
        return registrar_feedback(texto, tipo="correcao")

    if any(x in t for x in (
        "se auto aprimore", "se auto-aprimore", "auto aprimore", "autoaperfeiçoe",
        "autoaperfeicoe", "melhore a si mesmo", "melhore a si mesma",
        "aprimorar sistema", "rode autoaperfeiçoamento", "rode autoaperfeicoamento",
        "analise melhorias", "analise as melhorias",
    )):
        motivo = ""
        for sep in (" sobre ", " com ", ":"):
            if sep in t:
                motivo = texto.split(sep, 1)[1].strip()
                break
        return ciclo_autoaperfeicoar(motivo)

    if any(x in t for x in ("listar propostas", "mostrar propostas", "propostas de melhoria", "minhas propostas")):
        return listar_propostas()

    if any(x in t for x in ("listar feedback", "meu feedback", "feedbacks registrados")):
        return listar_feedback()

    m = re.match(r"^\s*aplicar melhoria(?:\s+([a-f0-9]+))?\s*$", t)
    if m or t in ("aplicar melhorias", "aplica melhoria", "aplica melhorias", "confirmar melhoria", "confirmar melhorias"):
        pid = m.group(1) if m and m.lastindex else None
        return aplicar_propostas(pid)

    m = re.match(r"^\s*rejeitar melhoria(?:\s+([a-f0-9]+))?\s*$", t)
    if m or t in ("rejeitar melhorias", "descartar propostas"):
        pid = m.group(1) if m and m.lastindex else None
        return rejeitar_propostas(pid)

    if any(x in t for x in ("como funciona o autoaperfeiçoamento", "como funciona autoaperfeicoamento", "o que é auto aprimorar")):
        return (
            "Eu registro seu feedback, proponho melhorias e só aplico as seguras com sua confirmação.\n"
            "Seguro: correções de fala, preferências, fatos, plugins simples, conhecimento JSON.\n"
            "Código do núcleo (jarvis.py): só gero arquivo em propostas/ — você revisa.\n"
            "Comandos: se auto aprimore | listar propostas | aplicar melhoria | rejeitar melhoria."
        )

    return None


def iniciar_servicos_autoaperfeicoar(**kwargs):
    configurar(**kwargs)
    _log("Módulo de autoaperfeiçoamento pronto.")
