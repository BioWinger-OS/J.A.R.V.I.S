#!/usr/bin/env python3
"""
Cadastro e expansão do banco de voz do dono — Jarvis 1.0
=======================================================
- Opção 1: cadastro completo (várias frases → banco maior)
- Opção 2: adicionar mais amostras ao banco existente
- Opção 3: testar reconhecimento
- Opção 4: status do banco
"""

import json
import os
import tempfile
import time
import datetime
from pathlib import Path

import numpy as np

_SCRIPT_DIR = Path(__file__).resolve().parent
if (_SCRIPT_DIR / "jarvis.py").exists() or (_SCRIPT_DIR / "voices").exists():
    BASE_DIR = _SCRIPT_DIR
else:
    BASE_DIR = Path.home() / "Jarvis"

VOICE_DIR = BASE_DIR / "voices"
EMBEDDING_FILE = VOICE_DIR / "meu_embedding.npy"
BASE_EMBEDDING_FILE = VOICE_DIR / "meu_embedding_base.npy"
ADAPTIVE_EMBEDDING_FILE = VOICE_DIR / "meu_embedding_adaptativo.npy"
BANK_DIR = VOICE_DIR / "banco"
BANK_INDEX = BANK_DIR / "indice.json"
CONFIG_FILE = VOICE_DIR / "voice_config.json"
THRESHOLD = 0.78
BANK_MAX = 40

# Frases variadas para capturar timbre, ritmo e volume diferentes
FRASES_CADASTRO = [
    "Olá Jarvis, este é o cadastro da minha voz.",
    "Por favor, reconheça apenas a minha voz a partir de agora.",
    "Hoje está um bom dia para programar e automatizar tarefas.",
    "Jarvis, abra o navegador e pesquise inteligência artificial.",
    "Um dois três quatro cinco, testando volume normal.",
    "Falando um pouco mais baixo para variar o perfil.",
    "Agora falo um pouco mais rápido sobre tecnologia e jogos.",
    "Última frase do cadastro: memoriza bem a minha voz.",
]


def salvar_embedding(caminho, embedding):
    caminho = Path(caminho)
    caminho.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(suffix=".npy", dir=str(caminho.parent), delete=False) as tmp:
        temporario = tmp.name
    try:
        np.save(temporario, embedding)
        os.replace(temporario, str(caminho))
    finally:
        if os.path.exists(temporario):
            os.unlink(temporario)


def normalizar(emb):
    v = np.asarray(emb, dtype=np.float32).reshape(-1)
    n = float(np.linalg.norm(v)) + 1e-8
    return v / n


def verificar_dependencias():
    try:
        import sounddevice  # noqa: F401
        import scipy  # noqa: F401
        import resemblyzer  # noqa: F401
        return True
    except ImportError as e:
        print(f"Dependência ausente: {e}")
        print("Instale: python -m pip install resemblyzer sounddevice scipy numpy")
        return False


def carregar_indice():
    if BANK_INDEX.exists():
        try:
            data = json.loads(BANK_INDEX.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                return data
        except Exception:
            pass
    return {"amostras": [], "criado_em": datetime.datetime.now().isoformat()}


def salvar_indice(indice):
    BANK_DIR.mkdir(parents=True, exist_ok=True)
    BANK_INDEX.write_text(json.dumps(indice, ensure_ascii=False, indent=2), encoding="utf-8")


def gravar_trecho(segundos=4.5, prompt=""):
    import sounddevice as sd
    from resemblyzer import VoiceEncoder, preprocess_wav
    from scipy.io.wavfile import write

    if prompt:
        print(f"\n→ Fale: \"{prompt}\"")
    else:
        print("\n→ Fale agora...")
    for n in (3, 2, 1):
        print(f"  {n}...")
        time.sleep(0.7)

    sr = 16000
    gravacao = sd.rec(int(segundos * sr), samplerate=sr, channels=1, dtype="float32")
    sd.wait()
    gravacao = gravacao.reshape(-1)
    energia = float(np.sqrt(np.mean(np.square(gravacao))))
    if energia < 0.004:
        print("  (muito baixo / silêncio — trecho ignorado)")
        return None

    temporario = None
    try:
        with tempfile.NamedTemporaryFile(suffix=".wav", dir=str(VOICE_DIR), delete=False) as tmp:
            temporario = tmp.name
        write(temporario, sr, (gravacao * 32767).astype(np.int16))
        emb = VoiceEncoder().embed_utterance(preprocess_wav(Path(temporario))).astype(np.float32)
        return normalizar(emb)
    finally:
        if temporario and os.path.exists(temporario):
            os.unlink(temporario)


def adicionar_ao_banco(emb, origem="cadastro", rotulo=""):
    indice = carregar_indice()
    # evita quase-duplicatas
    for item in indice.get("amostras", []):
        caminho = BANK_DIR / item.get("arquivo", "")
        if caminho.exists():
            try:
                antigo = normalizar(np.load(str(caminho), allow_pickle=False))
                if float(np.dot(antigo, emb)) >= 0.97:
                    return False
            except Exception:
                pass

    ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    nome = f"amostra_{ts}.npy"
    salvar_embedding(BANK_DIR / nome, emb)
    indice.setdefault("amostras", []).append({
        "arquivo": nome,
        "origem": origem,
        "rotulo": (rotulo or "")[:80],
        "criado_em": datetime.datetime.now().isoformat(),
    })
    if len(indice["amostras"]) > BANK_MAX:
        antigas = indice["amostras"][:-BANK_MAX]
        indice["amostras"] = indice["amostras"][-BANK_MAX:]
        for a in antigas:
            try:
                (BANK_DIR / a["arquivo"]).unlink(missing_ok=True)
            except Exception:
                pass
    salvar_indice(indice)
    return True


def atualizar_perfis_medios():
    """Recalcula base + adaptativo a partir do banco (ou legados)."""
    indice = carregar_indice()
    embs = []
    for item in indice.get("amostras", []):
        caminho = BANK_DIR / item.get("arquivo", "")
        if caminho.exists():
            try:
                embs.append(normalizar(np.load(str(caminho), allow_pickle=False)))
            except Exception:
                pass
    if not embs:
        return False
    matriz = np.stack(embs, axis=0)
    media = normalizar(np.mean(matriz, axis=0))
    for caminho in (EMBEDDING_FILE, BASE_EMBEDDING_FILE, ADAPTIVE_EMBEDDING_FILE):
        salvar_embedding(caminho, media)
    CONFIG_FILE.write_text(json.dumps({
        "threshold": THRESHOLD,
        "ativo": True,
        "amostras_banco": len(embs),
        "atualizado_em": datetime.datetime.now().isoformat(),
    }, ensure_ascii=False, indent=2), encoding="utf-8")
    return True


def cadastro_completo():
    """Várias frases → banco rico + perfis base/adaptativo."""
    VOICE_DIR.mkdir(parents=True, exist_ok=True)
    BANK_DIR.mkdir(parents=True, exist_ok=True)
    print("=" * 56)
    print("  CADASTRO COMPLETO DA VOZ (várias frases)")
    print("=" * 56)
    print("Fale sozinho, perto do microfone.")
    print("Use volume normal na maioria; uma frase mais baixa e uma mais rápida.")
    print(f"Serão {len(FRASES_CADASTRO)} trechos curtos.\n")
    input("Pressione ENTER para começar...")

    salvas = 0
    for i, frase in enumerate(FRASES_CADASTRO, 1):
        print(f"\n[{i}/{len(FRASES_CADASTRO)}]")
        emb = gravar_trecho(segundos=4.8, prompt=frase)
        if emb is None:
            print("  Tentando de novo este trecho...")
            emb = gravar_trecho(segundos=4.8, prompt=frase)
        if emb is not None:
            if adicionar_ao_banco(emb, origem="cadastro", rotulo=frase[:60]):
                salvas += 1
                print("  ✓ amostra salva")
            else:
                print("  ~ muito parecida com outra — ignorada")
        else:
            print("  ✗ falhou")

    if salvas < 2:
        print("\nPoucas amostras válidas. Tente de novo em ambiente mais silencioso.")
        return False

    atualizar_perfis_medios()
    print(f"\nPronto. {salvas} amostras no banco em {BANK_DIR}")
    print("Perfis base/adaptativo atualizados. WAV temporários foram apagados.")
    return True


def adicionar_amostras_extras(n=5):
    """Expande o banco sem apagar o que já existe."""
    if not BASE_EMBEDDING_FILE.exists() and not EMBEDDING_FILE.exists() and not BANK_INDEX.exists():
        print("Nenhum perfil ainda. Use o cadastro completo (opção 1).")
        return False

    print("=" * 56)
    print(f"  ADICIONAR {n} AMOSTRAS AO BANCO")
    print("=" * 56)
    print("Fale frases diferentes das do cadastro (comandos que você usa no dia a dia).")
    input("Pressione ENTER...")

    frases_extra = [
        "Jarvis, que horas são agora?",
        "Abre o YouTube e pesquisa música.",
        "Lembra que eu gosto de café.",
        "Modo foco por vinte e cinco minutos.",
        "Qual o status do sistema?",
        "Conta uma piada rápida.",
        "Iniciar com o Windows.",
        "Mostra meu perfil.",
    ]
    salvas = 0
    for i in range(n):
        frase = frases_extra[i % len(frases_extra)]
        print(f"\n[{i+1}/{n}]")
        emb = gravar_trecho(segundos=4.5, prompt=frase)
        if emb is not None and adicionar_ao_banco(emb, origem="expansao", rotulo=frase[:60]):
            salvas += 1
            print("  ✓ salva")
        else:
            print("  ✗ não salva")

    if salvas:
        atualizar_perfis_medios()
    print(f"\nAdicionadas {salvas}. Total no banco: {len(carregar_indice().get('amostras', []))}")
    return salvas > 0


def testar_reconhecimento():
    import sounddevice as sd
    from resemblyzer import VoiceEncoder, preprocess_wav
    from scipy.io.wavfile import write

    if not BASE_EMBEDDING_FILE.exists() and not EMBEDDING_FILE.exists():
        print("Nenhum perfil cadastrado. Use a opção 1.")
        return

    input("Pressione ENTER e fale por alguns segundos...")
    sr = 16000
    gravacao = sd.rec(5 * sr, samplerate=sr, channels=1, dtype="float32").reshape(-1)
    sd.wait()
    temporario = None
    try:
        with tempfile.NamedTemporaryFile(suffix=".wav", dir=str(VOICE_DIR), delete=False) as tmp:
            temporario = tmp.name
        write(temporario, sr, (gravacao * 32767).astype(np.int16))
        vetor = normalizar(VoiceEncoder().embed_utterance(preprocess_wav(Path(temporario))))
    finally:
        if temporario and os.path.exists(temporario):
            os.unlink(temporario)

    base_path = BASE_EMBEDDING_FILE if BASE_EMBEDDING_FILE.exists() else EMBEDDING_FILE
    atual_path = ADAPTIVE_EMBEDDING_FILE if ADAPTIVE_EMBEDDING_FILE.exists() else base_path
    base = normalizar(np.load(base_path, allow_pickle=False))
    atual = normalizar(np.load(atual_path, allow_pickle=False))
    score_atual = float(np.dot(atual, vetor))
    score_base = float(np.dot(base, vetor))

    scores_banco = []
    for item in carregar_indice().get("amostras", []):
        caminho = BANK_DIR / item.get("arquivo", "")
        if caminho.exists():
            try:
                scores_banco.append(float(np.dot(normalizar(np.load(str(caminho), allow_pickle=False)), vetor)))
            except Exception:
                pass
    scores_banco.sort(reverse=True)
    melhor = scores_banco[0] if scores_banco else score_atual
    top3 = scores_banco[:3] if scores_banco else [score_atual]
    media_top = sum(top3) / len(top3)

    print(f"Adaptativo: {score_atual:.3f} | Base: {score_base:.3f} | Banco max: {melhor:.3f} | Top3: {media_top:.3f}")
    print(f"Amostras no banco: {len(scores_banco)} | Limiar: {THRESHOLD:.2f}")
    ok = max(score_atual, melhor) >= THRESHOLD and score_base >= THRESHOLD - 0.12
    print("✓ Voz reconhecida." if ok else "✗ Voz não reconhecida.")


def status_banco():
    indice = carregar_indice()
    amostras = indice.get("amostras", [])
    print(f"Banco: {len(amostras)} amostra(s) (máx. {BANK_MAX})")
    print(f"Pasta: {BANK_DIR}")
    origens = {}
    for a in amostras:
        o = a.get("origem", "?")
        origens[o] = origens.get(o, 0) + 1
    for k, v in origens.items():
        print(f"  - {k}: {v}")
    print(f"Perfil base: {'sim' if BASE_EMBEDDING_FILE.exists() else 'não'}")
    print(f"Perfil adaptativo: {'sim' if ADAPTIVE_EMBEDDING_FILE.exists() else 'não'}")


def main():
    if not verificar_dependencias():
        return
    VOICE_DIR.mkdir(parents=True, exist_ok=True)
    BANK_DIR.mkdir(parents=True, exist_ok=True)
    cadastrado = BASE_EMBEDDING_FILE.exists() or EMBEDDING_FILE.exists() or BANK_INDEX.exists()

    print("=" * 56)
    print("  JARVIS 1.0 — Banco de voz do dono")
    print("=" * 56)
    print("1 - Cadastro completo (várias frases → banco maior)")
    print("2 - Adicionar mais amostras ao banco existente")
    if cadastrado:
        print("3 - Testar reconhecimento")
        print("4 - Status do banco")
    opcao = input("Escolha: ").strip()

    if opcao == "1":
        if cadastro_completo() and input("\nTestar agora? (s/n): ").strip().lower() == "s":
            testar_reconhecimento()
    elif opcao == "2":
        try:
            n = int(input("Quantas amostras extras? [5]: ").strip() or "5")
        except ValueError:
            n = 5
        n = max(1, min(15, n))
        if adicionar_amostras_extras(n) and input("\nTestar agora? (s/n): ").strip().lower() == "s":
            testar_reconhecimento()
    elif opcao == "3" and cadastrado:
        testar_reconhecimento()
    elif opcao == "4" and cadastrado:
        status_banco()
    else:
        print("Nada foi alterado.")


if __name__ == "__main__":
    main()
