#!/usr/bin/env python3
"""
J.A.R.V.I.S. - Versão 1.0
======================
Tudo da v4 + WhatsApp + Auto Atualização Inteligente
- Atualização manual por comando de voz
- Atualização automática 1x por dia
- Pesquisa → Resume → Salva no conhecimento
"""

import os
import sys
import json
import time
import threading
import subprocess
import datetime
import webbrowser
import tempfile
import numpy as np
from pathlib import Path
from rich.console import Console
from rich.panel import Panel

# ============================================================
# CAMINHOS
# ============================================================

BASE_DIR = Path.home() / "Jarvis"
MEMORY_DIR = BASE_DIR / "memory"
VOICE_DIR = BASE_DIR / "voices"
KNOWLEDGE_DIR = BASE_DIR / "conhecimento"
LOG_DIR = BASE_DIR / "logs"

MEMORY_FILE = MEMORY_DIR / "memoria.json"
REMINDERS_FILE = MEMORY_DIR / "lembretes.json"
CONTACTS_FILE = MEMORY_DIR / "contatos_whatsapp.json"
AUTO_UPDATE_FILE = MEMORY_DIR / "auto_update.json"
EMBEDDING_FILE = VOICE_DIR / "meu_embedding.npy"
CHROMA_DIR = MEMORY_DIR / "chroma_db"

for d in [MEMORY_DIR, VOICE_DIR, KNOWLEDGE_DIR, LOG_DIR, CHROMA_DIR]:
    d.mkdir(parents=True, exist_ok=True)

# ============================================================
# CONFIGURAÇÕES
# ============================================================

DEFAULT_MODEL = "qwen2.5:7b"
WAKE_WORDS = ["jarvis", "ei jarvis", "ok jarvis", "hey jarvis"]
VOICE_THRESHOLD = 0.78
USAR_RECONHECIMENTO_VOZ = True
MODO_PROATIVO = True
STT_ENGINE = "vosk"

# Auto atualização
AUTO_UPDATE_ATIVO = True          # True = atualiza sozinho 1x por dia
AUTO_UPDATE_HORA = 9               # Horário preferido (9h da manhã)

console = Console()

# ============================================================
# AUTO ATUALIZAÇÃO INTELIGENTE
# ============================================================

def carregar_status_auto_update():
    if AUTO_UPDATE_FILE.exists():
        try:
            with open(AUTO_UPDATE_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except:
            pass
    return {"ultima_atualizacao": None, "historico": []}

def salvar_status_auto_update(data):
    with open(AUTO_UPDATE_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def pesquisar_web(query, max_results=5):
    """Pesquisa usando duckduckgo-search (leve e sem API key)."""
    try:
        from duckduckgo_search import DDGS
        with DDGS() as ddgs:
            resultados = list(ddgs.text(query, max_results=max_results))
        return resultados
    except Exception as e:
        console.print(f"[yellow]Erro na pesquisa: {e}[/]")
        return []

def gerar_temas_relevantes():
    """Analisa a memória do usuário e gera temas relevantes para pesquisar."""
    memoria = carregar_memoria()
    fatos = [f["texto"] for f in memoria.get("fatos", [])[-20:]]
    aprendizados = [a["texto"] for a in memoria.get("aprendizados", [])[-15:]]
    todos = fatos + aprendizados

    if not todos:
        # Temas padrão se ainda não souber nada do usuário
        return [
            "principais notícias de tecnologia hoje",
            "novidades em inteligência artificial",
            "lançamentos importantes de tecnologia"
        ]

    # Pede para o modelo sugerir temas
    contexto = "\n".join(f"- {t}" for t in todos[:15])
    prompt = f"""Com base nas informações abaixo sobre o usuário, sugira 3 temas relevantes para pesquisar na internet e trazer novidades úteis.
Responda APENAS com os 3 temas, um por linha, sem numeração e sem explicação.

Informações do usuário:
{contexto}
"""
    try:
        result = subprocess.run(
            ["ollama", "run", DEFAULT_MODEL, prompt],
            capture_output=True, text=True, timeout=45,
            encoding="utf-8", errors="ignore"
        )
        linhas = [l.strip() for l in result.stdout.strip().splitlines() if l.strip()]
        temas = [l for l in linhas if len(l) > 10][:3]
        return temas if temas else ["novidades em inteligência artificial"]
    except:
        return ["novidades em inteligência artificial"]

def resumir_e_salvar(tema, resultados):
    """Usa o modelo para resumir os resultados e salvar no conhecimento."""
    if not resultados:
        return None

    textos = []
    for r in resultados[:4]:
        titulo = r.get("title", "")
        corpo = r.get("body", "")
        textos.append(f"{titulo}\n{corpo}")

    conteudo_bruto = "\n\n".join(textos)

    prompt = f"""Você é um assistente que resume informações de forma clara e útil.
Resuma as informações abaixo sobre o tema "{tema}" em um texto objetivo (máximo 2 parágrafos).
Foque no que é mais importante e atual.

Informações:
{conteudo_bruto[:3000]}
"""
    try:
        result = subprocess.run(
            ["ollama", "run", DEFAULT_MODEL, prompt],
            capture_output=True, text=True, timeout=60,
            encoding="utf-8", errors="ignore"
        )
        resumo = result.stdout.strip()
        if len(resumo) < 30:
            return None

        # Salva como arquivo JSON de conhecimento
        data_hoje = datetime.datetime.now().strftime("%Y-%m-%d")
        nome_arquivo = f"auto_{data_hoje}_{tema[:30].replace(' ', '_')}.json"
        # Limpa caracteres inválidos no nome
        nome_arquivo = "".join(c for c in nome_arquivo if c.isalnum() or c in "._-")

        caminho = KNOWLEDGE_DIR / nome_arquivo
        dados = {
            "titulo": f"Auto atualização: {tema}",
            "conteudo": resumo,
            "tags": ["auto-update", "pesquisa"],
            "data": datetime.datetime.now().isoformat(),
            "fonte": "pesquisa automática"
        }
        with open(caminho, "w", encoding="utf-8") as f:
            json.dump(dados, f, ensure_ascii=False, indent=2)

        # Também salva na memória vetorial
        adicionar_memoria_vetorial(resumo, {"tipo": "auto_update", "tema": tema})
        adicionar_fato(f"Aprendizado automático sobre: {tema}", fonte="auto_update")

        return resumo
    except Exception as e:
        console.print(f"[yellow]Erro ao resumir: {e}[/]")
        return None

def executar_auto_atualizacao(tema_especifico=None):
    """
    Executa a atualização.
    Se tema_especifico for passado, pesquisa só aquele tema.
    Caso contrário, gera temas relevantes automaticamente.
    """
    console.print("[cyan]Iniciando auto atualização...[/]")

    if tema_especifico:
        temas = [tema_especifico]
    else:
        temas = gerar_temas_relevantes()

    resultados_finais = []
    for tema in temas:
        console.print(f"[dim]Pesquisando: {tema}[/]")
        resultados = pesquisar_web(tema, max_results=5)
        resumo = resumir_e_salvar(tema, resultados)
        if resumo:
            resultados_finais.append({"tema": tema, "resumo": resumo})

    # Atualiza status
    status = carregar_status_auto_update()
    status["ultima_atualizacao"] = datetime.datetime.now().isoformat()
    status["historico"] = status.get("historico", [])[-20:]
    status["historico"].append({
        "data": datetime.datetime.now().isoformat(),
        "temas": [r["tema"] for r in resultados_finais]
    })
    salvar_status_auto_update(status)

    return resultados_finais

def thread_auto_update():
    """Thread que verifica se deve atualizar automaticamente."""
    while True:
        try:
            if AUTO_UPDATE_ATIVO:
                status = carregar_status_auto_update()
                agora = datetime.datetime.now()
                precisa_atualizar = False

                if not status.get("ultima_atualizacao"):
                    # Nunca atualizou → atualiza se estiver no horário
                    if agora.hour == AUTO_UPDATE_HORA:
                        precisa_atualizar = True
                else:
                    ultima = datetime.datetime.fromisoformat(status["ultima_atualizacao"])
                    # Já passou mais de 20 horas desde a última
                    if (agora - ultima).total_seconds() > 20 * 3600:
                        if agora.hour == AUTO_UPDATE_HORA:
                            precisa_atualizar = True

                if precisa_atualizar:
                    console.print("[cyan]Auto atualização programada iniciada...[/]")
                    resultados = executar_auto_atualizacao()
                    if resultados:
                        falar(f"Atualizei meus conhecimentos. Aprendi sobre {len(resultados)} temas novos.")
        except Exception as e:
            console.print(f"[yellow]Erro no auto update: {e}[/]")

        time.sleep(1800)  # Verifica a cada 30 minutos

# ============================================================
# WHATSAPP (mantido da v4)
# ============================================================

def carregar_contatos():
    if CONTACTS_FILE.exists():
        try:
            with open(CONTACTS_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except:
            pass
    return {}

def salvar_contatos(contatos):
    with open(CONTACTS_FILE, "w", encoding="utf-8") as f:
        json.dump(contatos, f, ensure_ascii=False, indent=2)

def adicionar_contato(nome, numero):
    contatos = carregar_contatos()
    contatos[nome.lower().strip()] = str(numero).strip()
    salvar_contatos(contatos)
    return f"Contato '{nome}' salvo com o número {numero}."

def listar_contatos():
    contatos = carregar_contatos()
    if not contatos:
        return "Nenhum contato salvo ainda."
    return "Contatos salvos:\n" + "\n".join(f"- {n.title()}: {num}" for n, num in contatos.items())

def enviar_mensagem_whatsapp(destinatario, mensagem):
    try:
        import pywhatkit as kit
    except ImportError:
        return "Biblioteca pywhatkit não instalada. Rode: pip install pywhatkit"
    contatos = carregar_contatos()
    chave = destinatario.lower().strip()
    numero = contatos.get(chave) or "".join(filter(str.isdigit, destinatario))
    if len(numero) < 10:
        return f"Não encontrei o contato '{destinatario}'."
    try:
        kit.sendwhatmsg_instantly(phone_no=f"+{numero}", message=mensagem, wait_time=15, tab_close=True, close_time=3)
        return f"Mensagem enviada para {destinatario}."
    except Exception as e:
        return f"Erro ao enviar: {e}"

def processar_whatsapp(texto):
    t = texto.lower().strip()
    if any(x in t for x in ["cadastra contato", "adicionar contato", "salva contato"]):
        partes = t
        for g in ["cadastra contato", "adicionar contato", "salva contato"]:
            partes = partes.replace(g, "")
        partes = partes.strip().split()
        if len(partes) >= 2:
            return adicionar_contato(" ".join(partes[:-1]), partes[-1])
        return "Exemplo: cadastra contato mãe 5511999998888"
    if any(x in t for x in ["lista contatos", "meus contatos"]):
        return listar_contatos()
    gatilhos = ["manda mensagem para", "envia mensagem para", "manda zap para", "envia zap para", "manda msg para"]
    for g in gatilhos:
        if g in t:
            resto = t.split(g, 1)[1].strip()
            for sep in [" falando ", " dizendo ", " que ", ": ", " fala "]:
                if sep in resto:
                    dest, msg = resto.split(sep, 1)
                    return enviar_mensagem_whatsapp(dest.strip(), msg.strip())
            pedacos = resto.split(maxsplit=1)
            if len(pedacos) == 2:
                return enviar_mensagem_whatsapp(pedacos[0], pedacos[1])
    return None

# ============================================================
# CONHECIMENTO JSON / MEMÓRIA (simplificado)
# ============================================================

def carregar_conhecimento_json():
    conhecimentos = []
    for arquivo in KNOWLEDGE_DIR.glob("*.json"):
        try:
            with open(arquivo, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, dict):
                conhecimentos.append({
                    "titulo": data.get("titulo") or arquivo.stem,
                    "conteudo": data.get("conteudo") or data.get("content") or str(data)
                })
        except:
            pass
    return conhecimentos

def obter_contexto_conhecimento():
    lista = carregar_conhecimento_json()
    if not lista:
        return ""
    partes = ["\n=== CONHECIMENTO ==="]
    for item in lista[-8:]:  # últimos 8
        texto = item["conteudo"][:1200]
        partes.append(f"\n[{item['titulo']}]\n{texto}")
    return "\n".join(partes)

def carregar_memoria():
    if MEMORY_FILE.exists():
        try:
            with open(MEMORY_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except:
            pass
    return {"fatos": [], "preferencias": {}, "historico": [], "aprendizados": []}

def salvar_memoria(memoria):
    with open(MEMORY_FILE, "w", encoding="utf-8") as f:
        json.dump(memoria, f, ensure_ascii=False, indent=2)

def adicionar_fato(texto, fonte="manual"):
    memoria = carregar_memoria()
    memoria["fatos"].append({"texto": texto, "fonte": fonte, "data": datetime.datetime.now().isoformat()})
    memoria["fatos"] = memoria["fatos"][-150:]
    salvar_memoria(memoria)

def adicionar_aprendizado(texto):
    memoria = carregar_memoria()
    memoria["aprendizados"].append({"texto": texto, "data": datetime.datetime.now().isoformat()})
    memoria["aprendizados"] = memoria["aprendizados"][-80:]
    salvar_memoria(memoria)

def obter_contexto_memoria():
    memoria = carregar_memoria()
    partes = [f"- {f['texto']}" for f in memoria.get("fatos", [])[-12:]]
    partes += [f"- {a['texto']}" for a in memoria.get("aprendizados", [])[-8:]]
    return "Informações sobre o usuário:\n" + "\n".join(partes) if partes else ""

# ChromaDB
_collection = None
def init_chroma():
    global _collection
    if _collection: return True
    try:
        import chromadb
        client = chromadb.PersistentClient(path=str(CHROMA_DIR))
        _collection = client.get_or_create_collection("jarvis_memory")
        return True
    except: return False

def adicionar_memoria_vetorial(texto, metadados=None):
    if not init_chroma(): return
    try:
        import uuid
        meta = metadados or {}
        meta["data"] = datetime.datetime.now().isoformat()
        _collection.add(documents=[texto], metadatas=[meta], ids=[str(uuid.uuid4())])
    except: pass

def buscar_memoria_vetorial(query, n=3):
    if not init_chroma(): return []
    try:
        r = _collection.query(query_texts=[query], n_results=n)
        return r.get("documents", [[]])[0]
    except: return []

def extrair_aprendizados(texto_usuario, resposta_jarvis):
    prompt = f"""Extraia APENAS informações importantes sobre o usuário. Se nada relevante: NENHUM

Usuário: {texto_usuario}
Jarvis: {resposta_jarvis}
"""
    try:
        result = subprocess.run(["ollama", "run", DEFAULT_MODEL, prompt],
                                capture_output=True, text=True, timeout=40, encoding="utf-8", errors="ignore")
        for linha in result.stdout.strip().splitlines():
            if linha.strip().startswith("- "):
                fato = linha.strip()[2:].strip()
                if len(fato) > 4:
                    adicionar_aprendizado(fato)
                    adicionar_fato(fato, "automatico")
                    adicionar_memoria_vetorial(fato, {"tipo": "aprendizado"})
    except: pass

# ============================================================
# LEMBRETES / VOLUME / MÍDIA (mantidos)
# ============================================================

def carregar_lembretes():
    if REMINDERS_FILE.exists():
        try:
            with open(REMINDERS_FILE, "r", encoding="utf-8") as f: return json.load(f)
        except: pass
    return []

def salvar_lembretes(lista):
    with open(REMINDERS_FILE, "w", encoding="utf-8") as f:
        json.dump(lista, f, ensure_ascii=False, indent=2)

def adicionar_lembrete(texto, minutos):
    lembretes = carregar_lembretes()
    disparo = datetime.datetime.now() + datetime.timedelta(minutes=minutos)
    lembretes.append({"texto": texto, "disparo": disparo.isoformat()})
    salvar_lembretes(lembretes)
    return f"Lembrete criado: '{texto}' em {minutos} minutos."

def thread_lembretes():
    while True:
        try:
            lembretes = carregar_lembretes()
            agora = datetime.datetime.now()
            disparar, restantes = [], []
            for l in lembretes:
                try:
                    if agora >= datetime.datetime.fromisoformat(l["disparo"]):
                        disparar.append(l["texto"])
                    else: restantes.append(l)
                except: restantes.append(l)
            if disparar:
                salvar_lembretes(restantes)
                for t in disparar:
                    falar(f"Lembrete: {t}")
        except: pass
        time.sleep(20)

def controlar_volume(acao):
    try:
        from ctypes import cast, POINTER
        from comtypes import CLSCTX_ALL
        from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume
        vol = cast(AudioUtilities.GetSpeakers().Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None), POINTER(IAudioEndpointVolume))
        atual = vol.GetMasterVolumeLevelScalar()
        if acao == "aumentar":
            vol.SetMasterVolumeLevelScalar(min(1.0, atual+0.1), None)
            return f"Volume em {int(min(1.0,atual+0.1)*100)}%."
        if acao == "diminuir":
            vol.SetMasterVolumeLevelScalar(max(0.0, atual-0.1), None)
            return f"Volume em {int(max(0.0,atual-0.1)*100)}%."
        if acao == "mudo":
            vol.SetMute(1, None)
            return "Som mutado."
        if acao == "desmudo":
            vol.SetMute(0, None)
            return "Som restaurado."
    except:
        pass
    return "Não consegui controlar o volume."

def controlar_midia(acao):
    try:
        import win32api, win32con
        VK = {"play": 0xB3, "proxima": 0xB0, "anterior": 0xB1}
        if acao in VK:
            win32api.keybd_event(VK[acao], 0, 0, 0)
            win32api.keybd_event(VK[acao], 0, win32con.KEYEVENTF_KEYUP, 0)
            return f"Mídia: {acao}."
    except: pass
    return "Não consegui controlar a mídia."

# ============================================================
# VOZ / STT / TTS
# ============================================================

_voice_encoder = _ref_embedding = None

def carregar_perfil_voz():
    global _voice_encoder, _ref_embedding
    if _ref_embedding is not None: return True
    if not EMBEDDING_FILE.exists(): return False
    try:
        from resemblyzer import VoiceEncoder
        _voice_encoder = VoiceEncoder()
        _ref_embedding = np.load(str(EMBEDDING_FILE))
        return True
    except: return False

def verificar_se_e_eu(audio_np, sr=16000):
    if not USAR_RECONHECIMENTO_VOZ or not carregar_perfil_voz(): return True
    try:
        from resemblyzer import preprocess_wav
        from scipy.io.wavfile import write
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp:
            write(tmp.name, sr, (audio_np*32767).astype(np.int16) if audio_np.dtype != np.int16 else audio_np)
            wav = preprocess_wav(Path(tmp.name))
            emb = _voice_encoder.embed_utterance(wav)
            sim = float(np.dot(_ref_embedding, emb)/(np.linalg.norm(_ref_embedding)*np.linalg.norm(emb)))
            try: os.unlink(tmp.name)
            except: pass
            return sim >= VOICE_THRESHOLD
    except: return True

_tts = None
def falar(texto):
    global _tts
    console.print(f"[bold cyan]Jarvis:[/] {texto}")
    try:
        if _tts is None:
            import pyttsx3
            _tts = pyttsx3.init()
            _tts.setProperty('rate', 175)
        _tts.say(texto)
        _tts.runAndWait()
    except Exception as e:
        console.print(f"[red]TTS: {e}[/]")

def ouvir(timeout=6):
    import sounddevice as sd
    try:
        from vosk import Model, KaldiRecognizer
        model_path = BASE_DIR / "vosk-model"
        if not model_path.exists():
            for p in [BASE_DIR/"vosk-model-small-pt", BASE_DIR/"model"]:
                if p.exists(): model_path = p; break
        if not model_path.exists():
            console.print("[yellow]Modelo Vosk não encontrado.[/]")
            return ""
        rec = KaldiRecognizer(Model(str(model_path)), 16000)
        console.print("[dim]Ouvindo...[/]")
        grav = sd.rec(int(timeout*16000), samplerate=16000, channels=1, dtype='int16')
        sd.wait()
        if not verificar_se_e_eu(grav.astype(np.float32).flatten()/32768.0):
            console.print("[dim]Voz não reconhecida.[/]")
            return None
        rec.AcceptWaveform(grav.tobytes())
        texto = json.loads(rec.FinalResult()).get("text", "").strip()
        if texto: console.print(f"[bold green]Você:[/] {texto}")
        return texto.lower() if texto else ""
    except Exception as e:
        console.print(f"[red]STT: {e}[/]")
        return ""

# ============================================================
# CÉREBRO + COMANDOS
# ============================================================

def perguntar_ia(pergunta):
    contexto = obter_contexto_memoria() + obter_contexto_conhecimento()
    mem = buscar_memoria_vetorial(pergunta)
    if mem: contexto += "\n\nMemórias:\n" + "\n".join(f"- {m}" for m in mem)
    prompt = f"""Você é o J.A.R.V.I.S. Responda em português brasileiro, educado e levemente sarcástico.

{contexto}

Usuário: {pergunta}
Jarvis:"""
    try:
        r = subprocess.run(["ollama", "run", DEFAULT_MODEL, prompt],
                           capture_output=True, text=True, timeout=90, encoding="utf-8", errors="ignore")
        resp = r.stdout.strip()
        return resp.split("Jarvis:")[-1].strip() if "Jarvis:" in resp else resp or "Não consegui processar."
    except Exception as e: return f"Erro: {e}"

def processar_comando(texto):
    t = texto.lower().strip()

    # WhatsApp
    resp = processar_whatsapp(t)
    if resp: return resp

    # Auto atualização
    if any(x in t for x in ["se atualize", "atualize seus conhecimentos", "pesquise novidades", "se atualiza"]):
        tema = None
        for sep in [" sobre ", " de ", " a respeito de "]:
            if sep in t:
                tema = t.split(sep, 1)[1].strip()
                break
        falar("Certo, vou pesquisar e atualizar meus conhecimentos. Isso pode levar alguns segundos.")
        resultados = executar_auto_atualizacao(tema)
        if resultados:
            temas = ", ".join(r["tema"] for r in resultados)
            return f"Atualização concluída. Aprendi sobre: {temas}."
        return "Não encontrei informações novas relevantes no momento."

    if "o que você aprendeu" in t or "o que você atualizou" in t or "últimas atualizações" in t:
        status = carregar_status_auto_update()
        if not status.get("historico"):
            return "Ainda não fiz nenhuma auto atualização."
        ultimo = status["historico"][-1]
        temas = ", ".join(ultimo.get("temas", []))
        data = ultimo.get("data", "")[:16].replace("T", " ")
        return f"Última atualização em {data}. Temas: {temas}."

    if any(w in t for w in ["desligar", "sair", "encerrar", "tchau"]):
        falar("Até logo, senhor.")
        sys.exit(0)

    if "que horas" in t: return f"Agora são {datetime.datetime.now().strftime('%H:%M')}."
    if "que dia" in t or "data de hoje" in t: return f"Hoje é {datetime.datetime.now().strftime('%d de %B de %Y')}."
    if "status do sistema" in t:
        try:
            import psutil
            return f"CPU {psutil.cpu_percent()}% | RAM {psutil.virtual_memory().percent}%"
        except: return "Não consegui obter o status."

    if "aumenta o volume" in t: return controlar_volume("aumentar")
    if "diminui o volume" in t: return controlar_volume("diminuir")
    if "muta" in t or "silencia" in t: return controlar_volume("mudo")
    if "desmuta" in t: return controlar_volume("desmudo")
    if "pausa" in t or "play" in t: return controlar_midia("play")
    if "próxima" in t: return controlar_midia("proxima")
    if "anterior" in t: return controlar_midia("anterior")

    if any(x in t for x in ["me lembra", "lembrete", "me avisa"]):
        import re
        m = re.search(r"(?:me lembra|lembrete|me avisa).*?(?:de |que )?(.*?)(?: em | daqui a | daqui | após )(\d+)\s*(minuto|minutos|hora|horas)", t)
        if m:
            minutos = int(m.group(2)) * (60 if "hora" in m.group(3) else 1)
            return adicionar_lembrete(m.group(1).strip(), minutos)
        return "Exemplo: me lembra de beber água em 30 minutos."

    if t.startswith(("abra ", "abrir ")) or "abre o " in t:
        app = t.replace("abra ", "").replace("abrir ", "").replace("abre o ", "").replace("abre a ", "").strip()
        os.system(f'start "" "{app}"')
        return f"Abrindo {app}."
    if "abre o youtube" in t: webbrowser.open("https://youtube.com"); return "Abrindo youtube."
    if "abre o google" in t: webbrowser.open("https://google.com"); return "Abrindo google."
    if "abre o whatsapp" in t: webbrowser.open("https://web.whatsapp.com"); return "Abrindo WhatsApp."

    if t.startswith(("lembre que ", "lembra que ")):
        fato = t.replace("lembre que ", "").replace("lembra que ", "").strip()
        adicionar_fato(fato)
        adicionar_memoria_vetorial(fato)
        return f"Anotado. Vou lembrar que {fato}."
    if "o que você sabe sobre mim" in t:
        ctx = obter_contexto_memoria()
        return ctx if ctx else "Ainda estou aprendendo sobre você."

    return perguntar_ia(texto)

# ============================================================
# MAIN
# ============================================================

def main():
    tem_voz = carregar_perfil_voz()
    init_chroma()
    conhecimentos = carregar_conhecimento_json()
    status = carregar_status_auto_update()

    console.print(Panel.fit(
        "[bold cyan]J.A.R.V.I.S. v5[/]\n"
        "[dim]Auto Atualização + WhatsApp + Offline[/]\n\n"
        f"Modelo: {DEFAULT_MODEL}\n"
        f"Reconhecimento de voz: {'Ativo' if tem_voz else 'Off'}\n"
        f"Arquivos JSON: {len(conhecimentos)}\n"
        f"Auto Update: {'Ativo' if AUTO_UPDATE_ATIVO else 'Desligado'}\n"
        f"Última atualização: {status.get('ultima_atualizacao', 'Nunca')[:16] if status.get('ultima_atualizacao') else 'Nunca'}",
        title="Sistema Online", border_style="cyan"
    ))

    threading.Thread(target=thread_lembretes, daemon=True).start()
    threading.Thread(target=thread_auto_update, daemon=True).start()

    falar("Sistema Jarvis versão 1.0 online. Auto atualização ativada.")

    console.print("\n[bold]Novos comandos:[/]")
    console.print('  • "se atualize"')
    console.print('  • "se atualize sobre inteligência artificial"')
    console.print('  • "o que você aprendeu de novo?"\n')

    while True:
        try:
            texto = ouvir()
            if texto is None or not texto: continue
            for w in WAKE_WORDS:
                if texto.startswith(w):
                    texto = texto[len(w):].strip()
                    break
            if not texto:
                falar("Sim, senhor?")
                texto = ouvir(8)
                if not texto: continue

            resposta = processar_comando(texto)
            falar(resposta)

            memoria = carregar_memoria()
            memoria["historico"].append({"usuario": texto, "jarvis": resposta, "data": datetime.datetime.now().isoformat()})
            memoria["historico"] = memoria["historico"][-60:]
            salvar_memoria(memoria)
            try: extrair_aprendizados(texto, resposta)
            except: pass
            adicionar_memoria_vetorial(f"Usuário: {texto} | Jarvis: {resposta}")

        except KeyboardInterrupt:
            falar("Encerrando sistemas.")
            break
        except Exception as e:
            console.print(f"[red]Erro: {e}[/]")
            time.sleep(1)

if __name__ == "__main__":
    main()
