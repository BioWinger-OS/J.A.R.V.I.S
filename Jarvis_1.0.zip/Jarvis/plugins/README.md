# Plugins do Jarvis

O Jarvis carrega apenas os módulos declarados em `ativos.json`, ao iniciar.

Crie um arquivo `plugin_meunome.py` com uma função `processar(texto)`. Ela deve retornar uma resposta em texto quando reconhecer um comando, ou `None` para deixar o Jarvis continuar o fluxo normal. Depois, adicione o nome do módulo à lista `ativos` e reinicie o Jarvis.

Exemplo:

```python
def processar(texto):
    if texto.strip().lower() == "meu comando":
        return "Resposta do meu plugin."
    return None
```

Plugins Python rodam com os mesmos acessos do Jarvis. Ative somente código que você escreveu ou revisou.

O plugin `plugin_exemplo` já vem ativo. Digite `teste plugin` para confirmar que o carregador funciona.
