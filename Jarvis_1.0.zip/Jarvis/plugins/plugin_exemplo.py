"""Exemplo pequeno do formato de plugin do Jarvis."""


def processar(texto):
    if texto.strip().lower() in ("teste plugin", "teste de plugin"):
        return "Plugin local ativo e respondendo."
    return None
