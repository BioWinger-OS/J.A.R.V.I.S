#!/usr/bin/env python3
"""
Recursos Pro para Jarvis 1.0
=============================
1. Agente de tarefas (executa planos de verdade)
2. Notificações + aviso de compromisso 15 min antes
3. Leitura/resumo de PDF e documentos
4. Interface gráfica simples (orb/status)
5. Mãos livres total (sempre ouvindo com VAD)
"""

import os
import re
import json
import time
import queue
import threading
import datetime
import subprocess
import tempfile
from pathlib import Path

_SCRIPT_DIR = Path(__file__).resolve().parent
if (_SCRIPT_DIR / "jarvis.py").exists() or (_SCRIPT_DIR / "memory").exists():
    BASE_DIR = _SCRIPT_DIR
else:
    BASE_DIR = Path.home() / "Jarvis"
MEMORY_DIR = BASE_DIR / "memory"
AGENDA_FILE = MEMORY_DIR / "agenda.json"
NOTIF_FILE = MEMORY_DIR / "notificacoes.json"
AGENT_LOG = MEMORY_DIR / "agente_log.json"
DEFAULT_MODEL = os.environ.get("JARVIS_MODEL", "qwen2.5:7b")

# Estado global
_maos_livres = {"ativo": False, "thread": None, "stop": threading.Event()}
_gui_queue = queue.Queue()
_gui_started = False
_notif_enviadas = set()  # ids de compromissos já avisados

# Callbacks injetados pelo jarvis.py
_falar_cb = None
_processar_cb = None
_console = None


def configurar(falar_fn=None, processar_fn=None, console=None):
    global _falar_cb, _processar_cb, _console
    _falar_cb = falar_fn
    _processar_cb = processar_fn
    _console = console


def _log(msg):
    if _console:
        try:
            _console.print(f"[dim][Pro] {msg}[/]")
        except Exception:
            print(f"[Pro] {msg}")
    else:
        print(f"[Pro] {msg}")


def _falar(texto):
    if _falar_cb:
        _falar_cb(texto)
    else:
        print(f"Jarvis: {texto}")


# ============================================================
# 1. AGENTE DE TAREFAS (executa planos)
# ============================================================

ACOES_SEGURAS = {
    "abrir_pasta", "listar_pasta", "criar_pasta", "abrir_app",
    "pesquisar_web", "abrir_url", "ler_arquivo", "resumo_pdf",
    "mover_arquivo", "copiar_arquivo", "renomear_arquivo",
    "digitar", "atalho", "esperar", "falar",
}

ACOES_PERIGOSAS = {"apagar_arquivo", "apagar_pasta", "desligar", "reiniciar"}


def _resolver_caminho(texto):
    home = Path.home()
    mapa = {
        "downloads": home / "Downloads",
        "documentos": home / "Documents",
        "documents": home / "Documents",
        "desktop": home / "Desktop",
        "área de trabalho": home / "Desktop",
        "area de trabalho": home / "Desktop",
        "imagens": home / "Pictures",
        "jarvis": BASE_DIR,
    }
    t = (texto or "").strip().lower()
    if t in mapa:
        return mapa[t]
    p = Path(texto).expanduser()
    if not p.is_absolute():
        p = home / p
    return p


def _executar_acao(acao: dict):
    """Executa uma ação do agente. Retorna string de resultado."""
    tipo = (acao.get("tipo") or "").lower().strip()
    args = acao.get("args") or {}

    try:
        if tipo == "falar":
            msg = args.get("texto", "")
            _falar(msg)
            return f"Falou: {msg[:80]}"

        if tipo == "esperar":
            seg = float(args.get("segundos", 1))
            time.sleep(min(seg, 30))
            return f"Esperou {seg}s"

        if tipo == "abrir_pasta":
            caminho = _resolver_caminho(args.get("caminho", "desktop"))
            if caminho.exists():
                os.startfile(str(caminho))
                return f"Abriu pasta {caminho}"
            return f"Pasta não encontrada: {caminho}"

        if tipo == "criar_pasta":
            caminho = _resolver_caminho(args.get("caminho"))
            caminho.mkdir(parents=True, exist_ok=True)
            return f"Pasta criada: {caminho}"

        if tipo == "listar_pasta":
            caminho = _resolver_caminho(args.get("caminho", "downloads"))
            if not caminho.exists():
                return f"Pasta inexistente: {caminho}"
            itens = list(caminho.iterdir())[:30]
            nomes = [x.name for x in itens]
            return f"Itens em {caminho.name}: " + ", ".join(nomes[:15])

        if tipo == "abrir_app":
            app = args.get("nome", "")
            os.system(f'start "" "{app}"')
            return f"Tentou abrir {app}"

        if tipo == "abrir_url":
            import webbrowser
            url = args.get("url", "https://google.com")
            if not url.startswith("http"):
                url = "https://" + url
            webbrowser.open(url)
            return f"Abriu URL {url}"

        if tipo == "pesquisar_web":
            import webbrowser
            q = args.get("query", "")
            webbrowser.open(f"https://www.google.com/search?q={q.replace(' ', '+')}")
            return f"Pesquisou: {q}"

        if tipo == "ler_arquivo":
            return ler_documento(args.get("caminho", ""))

        if tipo == "resumo_pdf":
            return resumir_documento(args.get("caminho", ""))

        if tipo == "mover_arquivo":
            src = _resolver_caminho(args.get("origem"))
            dst = _resolver_caminho(args.get("destino"))
            if not src.exists():
                return f"Origem não existe: {src}"
            dst.parent.mkdir(parents=True, exist_ok=True)
            src.rename(dst if dst.suffix else dst / src.name)
            return f"Moveu {src.name}"

        if tipo == "copiar_arquivo":
            import shutil
            src = _resolver_caminho(args.get("origem"))
            dst = _resolver_caminho(args.get("destino"))
            if not src.exists():
                return f"Origem não existe: {src}"
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dst if dst.suffix else dst / src.name)
            return f"Copiou {src.name}"

        if tipo == "renomear_arquivo":
            src = _resolver_caminho(args.get("origem"))
            novo = args.get("novo_nome", "")
            if not src.exists():
                return f"Arquivo não existe: {src}"
            dest = src.with_name(novo)
            src.rename(dest)
            return f"Renomeou para {novo}"

        if tipo == "digitar":
            import pyautogui
            time.sleep(0.3)
            texto = args.get("texto", "")
            try:
                pyautogui.write(texto, interval=0.02)
            except Exception:
                import pyperclip
                pyperclip.copy(texto)
                pyautogui.hotkey("ctrl", "v")
            return "Digitou texto"

        if tipo == "atalho":
            import pyautogui
            teclas = [k.strip() for k in str(args.get("teclas", "ctrl+c")).split("+")]
            pyautogui.hotkey(*teclas)
            return f"Atalho {'+'.join(teclas)}"

        if tipo in ACOES_PERIGOSAS:
            return f"Ação perigosa '{tipo}' bloqueada por segurança. Confirme manualmente se necessário."

        return f"Ação desconhecida: {tipo}"
    except Exception as e:
        return f"Erro em {tipo}: {e}"


def planejar_acoes(objetivo):
    """Pede ao modelo um plano executável em JSON."""
    prompt = f"""Você é um planejador de ações para um assistente no Windows.
Objetivo do usuário: {objetivo}

Responda APENAS com JSON válido neste formato:
{{
  "etapas": [
    {{"tipo": "abrir_pasta", "args": {{"caminho": "downloads"}}, "descricao": "Abrir Downloads"}},
    {{"tipo": "listar_pasta", "args": {{"caminho": "downloads"}}, "descricao": "Listar arquivos"}}
  ]
}}

Tipos permitidos (somente estes):
abrir_pasta, listar_pasta, criar_pasta, abrir_app, pesquisar_web, abrir_url,
ler_arquivo, resumo_pdf, mover_arquivo, copiar_arquivo, renomear_arquivo,
digitar, atalho, esperar, falar

Regras:
- 2 a 6 etapas no máximo
- Caminhos preferencialmente: downloads, documentos, desktop, imagens
- Não use ações destrutivas
- descricao em português, curta
"""
    try:
        r = subprocess.run(
            ["ollama", "run", DEFAULT_MODEL, prompt],
            capture_output=True, text=True, timeout=90,
            encoding="utf-8", errors="ignore"
        )
        saida = r.stdout.strip()
        i, j = saida.find("{"), saida.rfind("}")
        if i < 0 or j <= i:
            return None
        dados = json.loads(saida[i:j+1])
        etapas = dados.get("etapas", [])
        limpas = []
        for e in etapas[:6]:
            tipo = (e.get("tipo") or "").lower()
            if tipo in ACOES_SEGURAS:
                limpas.append({
                    "tipo": tipo,
                    "args": e.get("args") or {},
                    "descricao": e.get("descricao") or tipo,
                })
        return limpas if limpas else None
    except Exception as e:
        _log(f"Erro ao planejar: {e}")
        return None


def executar_plano_agente(objetivo, confirmar=True):
    """
    Cria e executa um plano de verdade.
    Retorna relatório em texto.
    """
    _gui_status(f"Planejando: {objetivo[:40]}...")
    etapas = planejar_acoes(objetivo)
    if not etapas:
        return "Não consegui montar um plano executável para isso. Tente ser mais específico."

    relatorio = [f"Plano para: {objetivo}"]
    for i, e in enumerate(etapas, 1):
        relatorio.append(f"  {i}. {e['descricao']} ({e['tipo']})")

    resultados = []
    for i, e in enumerate(etapas, 1):
        _gui_status(f"Executando {i}/{len(etapas)}: {e['descricao']}")
        _log(f"Agente etapa {i}: {e['tipo']} - {e['descricao']}")
        res = _executar_acao(e)
        resultados.append(f"{i}. {e['descricao']}: {res}")
        time.sleep(0.3)

    # salva log
    try:
        MEMORY_DIR.mkdir(parents=True, exist_ok=True)
        logs = []
        if AGENT_LOG.exists():
            logs = json.loads(AGENT_LOG.read_text(encoding="utf-8"))
        logs.append({
            "quando": datetime.datetime.now().isoformat(),
            "objetivo": objetivo,
            "etapas": etapas,
            "resultados": resultados,
        })
        AGENT_LOG.write_text(json.dumps(logs[-30:], ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception:
        pass

    _gui_status("Agente: concluído")
    return "Execução concluída:\n" + "\n".join(resultados)


# ============================================================
# 2. NOTIFICAÇÕES + COMPROMISSOS 15 MIN
# ============================================================

def _carregar_agenda():
    if AGENDA_FILE.exists():
        try:
            return json.loads(AGENDA_FILE.read_text(encoding="utf-8"))
        except Exception:
            pass
    return []


def _carregar_notifs():
    if NOTIF_FILE.exists():
        try:
            return json.loads(NOTIF_FILE.read_text(encoding="utf-8"))
        except Exception:
            pass
    return []


def _salvar_notifs(lista):
    MEMORY_DIR.mkdir(parents=True, exist_ok=True)
    NOTIF_FILE.write_text(json.dumps(lista, ensure_ascii=False, indent=2), encoding="utf-8")


def adicionar_notificacao(texto, minutos=0):
    """Notificação simples em X minutos (0 = agora)."""
    quando = datetime.datetime.now() + datetime.timedelta(minutes=max(0, int(minutos)))
    lista = _carregar_notifs()
    item = {
        "id": str(int(time.time() * 1000)),
        "texto": texto,
        "quando": quando.isoformat(),
        "enviada": False,
    }
    lista.append(item)
    _salvar_notifs(lista)
    if minutos <= 0:
        return f"Notificação: {texto}"
    return f"Vou te avisar em {minutos} minuto(s): {texto}"


def _toast_windows(titulo, msg):
    try:
        # PowerShell balloon tip
        ps = f'''
[void][System.Reflection.Assembly]::LoadWithPartialName('System.Windows.Forms')
$n = New-Object System.Windows.Forms.NotifyIcon
$n.Icon = [System.Drawing.SystemIcons]::Information
$n.Visible = $true
$n.ShowBalloonTip(5000, '{titulo.replace("'", "")}', '{msg.replace("'", "")[:120]}', [System.Windows.Forms.ToolTipIcon]::Info)
Start-Sleep -Seconds 6
$n.Dispose()
'''
        subprocess.Popen(
            ["powershell", "-NoProfile", "-Command", ps],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
        )
    except Exception:
        pass


def verificar_compromissos_e_notifs():
    """Chamado periodicamente. Avisa 15 min antes de compromissos e dispara notifs."""
    global _notif_enviadas
    agora = datetime.datetime.now()
    avisos = []

    # Agenda
    for item in _carregar_agenda():
        try:
            dt = datetime.datetime.fromisoformat(item["quando"])
            delta = (dt - agora).total_seconds()
            cid = item.get("id") or item["quando"] + item.get("titulo", "")
            # entre 14 e 16 minutos antes (janela)
            if 14 * 60 <= delta <= 16 * 60 and cid not in _notif_enviadas:
                titulo = item.get("titulo", "Compromisso")
                msg = f"Compromisso em 15 minutos: {titulo}"
                avisos.append(msg)
                _notif_enviadas.add(cid)
                _toast_windows("Jarvis — Compromisso", titulo)
                _gui_status(msg)
        except Exception:
            continue

    # Notificações manuais
    lista = _carregar_notifs()
    mudou = False
    for item in lista:
        if item.get("enviada"):
            continue
        try:
            dt = datetime.datetime.fromisoformat(item["quando"])
            if agora >= dt:
                msg = item.get("texto", "Lembrete")
                avisos.append(msg)
                item["enviada"] = True
                mudou = True
                _toast_windows("Jarvis", msg)
        except Exception:
            continue
    if mudou:
        _salvar_notifs(lista)

    for msg in avisos:
        try:
            _falar(msg)
        except Exception:
            pass
    return avisos


def thread_notificacoes():
    while True:
        try:
            verificar_compromissos_e_notifs()
        except Exception as e:
            _log(f"notif: {e}")
        time.sleep(30)


# ============================================================
# 3. LEITURA / RESUMO DE PDF E DOCUMENTOS
# ============================================================

def _extrair_texto_arquivo(caminho: Path, max_chars=12000):
    caminho = Path(caminho)
    if not caminho.exists():
        # tenta resolver atalhos
        caminho = _resolver_caminho(str(caminho))
    if not caminho.exists():
        return None, f"Arquivo não encontrado: {caminho}"

    ext = caminho.suffix.lower()
    texto = ""

    try:
        if ext == ".pdf":
            try:
                from pypdf import PdfReader
            except ImportError:
                try:
                    from PyPDF2 import PdfReader
                except ImportError:
                    return None, "Instale pypdf: pip install pypdf"
            reader = PdfReader(str(caminho))
            partes = []
            for page in reader.pages[:30]:
                partes.append(page.extract_text() or "")
            texto = "\n".join(partes)
        elif ext in (".txt", ".md", ".csv", ".log", ".py", ".json", ".html", ".css", ".js"):
            texto = caminho.read_text(encoding="utf-8", errors="ignore")
        elif ext in (".docx",):
            try:
                import docx
                doc = docx.Document(str(caminho))
                texto = "\n".join(p.text for p in doc.paragraphs)
            except ImportError:
                return None, "Instale python-docx: pip install python-docx"
        else:
            return None, f"Formato não suportado: {ext}. Use PDF, TXT, MD, DOCX."
    except Exception as e:
        return None, f"Erro ao ler arquivo: {e}"

    texto = re.sub(r"\n{3,}", "\n\n", texto).strip()
    if not texto:
        return None, "Não consegui extrair texto deste arquivo."
    return texto[:max_chars], None


def ler_documento(caminho_texto):
    texto, err = _extrair_texto_arquivo(caminho_texto)
    if err:
        return err
    if len(texto) > 1500:
        return texto[:1500] + "\n\n[... texto cortado; peça 'resume o arquivo' para resumo completo]"
    return texto


def resumir_documento(caminho_texto):
    texto, err = _extrair_texto_arquivo(caminho_texto, max_chars=10000)
    if err:
        return err
    prompt = f"""Resuma o documento abaixo em português, de forma clara e objetiva.
Traga os pontos principais em tópicos curtos.

DOCUMENTO:
{texto}
"""
    try:
        r = subprocess.run(
            ["ollama", "run", DEFAULT_MODEL, prompt],
            capture_output=True, text=True, timeout=120,
            encoding="utf-8", errors="ignore"
        )
        resumo = r.stdout.strip()
        return resumo if resumo else "Não consegui gerar o resumo."
    except Exception as e:
        return f"Erro ao resumir: {e}"


def buscar_pdf_recente(pasta="downloads"):
    caminho = _resolver_caminho(pasta)
    if not caminho.exists():
        return None
    pdfs = sorted(caminho.glob("*.pdf"), key=lambda p: p.stat().st_mtime, reverse=True)
    return pdfs[0] if pdfs else None


# ============================================================
# 4. INTERFACE GRÁFICA SIMPLES
# ============================================================

def _gui_status(msg):
    try:
        _gui_queue.put(("status", msg))
    except Exception:
        pass


def _gui_loop():
    """Orb/status window com tkinter."""
    try:
        import tkinter as tk
        from tkinter import ttk
    except Exception as e:
        _log(f"GUI indisponível: {e}")
        return

    root = tk.Tk()
    root.title("J.A.R.V.I.S.")
    root.geometry("320x180+40+40")
    root.attributes("-topmost", True)
    root.configure(bg="#0b1220")
    try:
        root.attributes("-alpha", 0.94)
    except Exception:
        pass

    titulo = tk.Label(root, text="J.A.R.V.I.S.", fg="#5eead4", bg="#0b1220",
                      font=("Segoe UI", 16, "bold"))
    titulo.pack(pady=(14, 4))

    status = tk.Label(root, text="Online", fg="#e2e8f0", bg="#0b1220",
                      font=("Segoe UI", 10), wraplength=280, justify="center")
    status.pack(pady=6)

    canvas = tk.Canvas(root, width=60, height=60, bg="#0b1220", highlightthickness=0)
    canvas.pack(pady=4)
    orb = canvas.create_oval(8, 8, 52, 52, fill="#14b8a6", outline="#5eead4", width=2)

    estado = {"fase": 0}

    def animar():
        estado["fase"] = (estado["fase"] + 1) % 20
        # pulso simples
        s = 1 + (0.08 if estado["fase"] < 10 else -0.08)
        # só recolor
        cor = "#14b8a6" if estado["fase"] % 4 < 2 else "#0d9488"
        canvas.itemconfig(orb, fill=cor)
        root.after(120, animar)

    def pump():
        try:
            while True:
                kind, payload = _gui_queue.get_nowait()
                if kind == "status":
                    status.config(text=str(payload)[:120])
                elif kind == "titulo":
                    titulo.config(text=str(payload)[:40])
                elif kind == "fechar":
                    root.destroy()
                    return
        except queue.Empty:
            pass
        root.after(200, pump)

    animar()
    pump()
    try:
        root.mainloop()
    except Exception:
        pass


def iniciar_gui():
    global _gui_started
    if _gui_started:
        return "Interface já está aberta."
    _gui_started = True
    t = threading.Thread(target=_gui_loop, daemon=True)
    t.start()
    _gui_status("Sistema online")
    return "Interface gráfica iniciada."


def fechar_gui():
    global _gui_started
    _gui_queue.put(("fechar", None))
    _gui_started = False
    return "Interface fechada."


# ============================================================
# 5. MÃOS LIVRES (sempre ouvindo)
# ============================================================

def ativar_maos_livres():
    if _maos_livres["ativo"]:
        return "Mãos livres já está ativo."
    _maos_livres["ativo"] = True
    _maos_livres["stop"].clear()
    _gui_status("Mãos livres: ouvindo")
    return (
        "Mãos livres ativado. Fico ouvindo em segundo plano. "
        "Diga Jarvis seguido do comando, ou apenas fale se a conversa contínua estiver ligada. "
        "Para desligar: 'desativa mãos livres'."
    )


def desativar_maos_livres():
    _maos_livres["ativo"] = False
    _maos_livres["stop"].set()
    _gui_status("Mãos livres: off")
    return "Mãos livres desativado."


def maos_livres_ativo():
    return bool(_maos_livres.get("ativo"))


# ============================================================
# PROCESSADOR DE COMANDOS PRO
# ============================================================

def processar_pro(texto):
    """Retorna resposta str ou None."""
    t = (texto or "").lower().strip()

    # --- Agente ---
    gatilhos_agente = [
        "executa a tarefa", "execute a tarefa", "faz a tarefa",
        "executar plano", "execute o plano", "age sobre",
        "organiza minha pasta", "organize minha pasta",
        "agente ", "roda o agente",
    ]
    for g in gatilhos_agente:
        if t.startswith(g) or g in t:
            objetivo = t
            for g2 in gatilhos_agente:
                objetivo = objetivo.replace(g2, "")
            objetivo = objetivo.strip(" .,!") or t
            # atalhos comuns
            if "downloads" in t and ("organiza" in t or "organize" in t):
                objetivo = "listar e descrever a pasta downloads"
            return executar_plano_agente(objetivo)

    m = re.search(r"(?:executa|execute|faz|faça|rode)\s+(?:isso|a tarefa|o plano)?\s*:?\s*(.+)", t)
    if m and any(x in t for x in ["pasta", "arquivo", "downloads", "organiza", "abre", "lista"]):
        return executar_plano_agente(m.group(1).strip())

    # --- Notificações ---
    m = re.search(r"(?:me avisa|me notifica|notifica(?:ção)?)\s+(.+?)(?:\s+em\s+(\d+)\s*minutos?)?$", t)
    if m:
        msg = m.group(1).strip()
        mins = int(m.group(2)) if m.group(2) else 0
        return adicionar_notificacao(msg, mins)

    if "testar notificação" in t or "testa notificação" in t:
        _toast_windows("Jarvis", "Notificação de teste")
        return "Notificação de teste enviada."

    # --- Documentos ---
    m = re.search(r"(?:resume|resumir|faça um resumo d[eo])\s+(?:o\s+)?(?:arquivo\s+|pdf\s+)?(.+)", t)
    if m and any(x in t for x in ["pdf", "arquivo", "documento", "texto", "downloads", ".pdf", ".txt", ".docx"]):
        caminho = m.group(1).strip().strip('"')
        if caminho in ("pdf", "o pdf", "ultimo pdf", "último pdf", "pdf recente"):
            pdf = buscar_pdf_recente("downloads")
            if not pdf:
                return "Não encontrei PDF recente em Downloads."
            caminho = str(pdf)
        return resumir_documento(caminho)

    m = re.search(r"(?:l[eê]|ler|leia)\s+(?:o\s+)?(?:arquivo\s+|pdf\s+|documento\s+)?(.+)", t)
    if m and any(x in t for x in ["pdf", "arquivo", "documento", ".pdf", ".txt", ".docx", "downloads"]):
        caminho = m.group(1).strip().strip('"')
        if "recente" in caminho or caminho in ("pdf", "o pdf"):
            pdf = buscar_pdf_recente("downloads")
            if not pdf:
                return "Não encontrei PDF recente."
            caminho = str(pdf)
        return ler_documento(caminho)

    if "resume o ultimo pdf" in t or "resume o último pdf" in t or "resumir pdf recente" in t:
        pdf = buscar_pdf_recente("downloads")
        if not pdf:
            return "Nenhum PDF em Downloads."
        return resumir_documento(str(pdf))

    # --- GUI ---
    if any(x in t for x in ["abre a interface", "abrir interface", "mostra a interface", "abre o painel"]):
        return iniciar_gui()
    if any(x in t for x in ["fecha a interface", "fechar interface", "esconde o painel"]):
        return fechar_gui()

    # --- Mãos livres ---
    if any(x in t for x in ["ativa mãos livres", "ativar mãos livres", "maos livres", "mãos livres",
                            "fica sempre ouvindo", "modo mãos livres"]):
        return ativar_maos_livres()
    if any(x in t for x in ["desativa mãos livres", "desativar mãos livres", "para mãos livres",
                            "desligar mãos livres"]):
        return desativar_maos_livres()

    return None


def iniciar_servicos_pro(falar_fn=None, processar_fn=None, console=None, gui=True):
    """Chamar no main() do Jarvis."""
    configurar(falar_fn, processar_fn, console)
    threading.Thread(target=thread_notificacoes, daemon=True).start()
    if gui:
        try:
            iniciar_gui()
        except Exception as e:
            _log(f"GUI: {e}")
    _log("Serviços Pro iniciados (notificações + GUI opcional)")
