#!/usr/bin/env python3
"""Teste rápido da voz do Jarvis (edge-tts + pygame)."""
import asyncio
import os
import tempfile
import time
from pathlib import Path

print("1) Instalando pygame se preciso...")
os.system("python -m pip install edge-tts pygame -q")

print("2) Gerando áudio com edge-tts...")
import edge_tts

mp3 = Path(tempfile.gettempdir()) / "teste_jarvis_voz.mp3"

async def gerar():
    c = edge_tts.Communicate(
        "Olá. Eu sou o Jarvis. Sistema online.",
        "pt-BR-AntonioNeural",
        rate="-5%",
    )
    await c.save(str(mp3))

asyncio.run(gerar())
print(f"   Arquivo: {mp3}")
print(f"   Tamanho: {mp3.stat().st_size} bytes")

if mp3.stat().st_size < 200:
    print("ERRO: arquivo de áudio vazio. Verifique a internet.")
    raise SystemExit(1)

print("3) Reproduzindo com pygame...")
import pygame
pygame.mixer.init()
pygame.mixer.music.load(str(mp3))
pygame.mixer.music.play()
while pygame.mixer.music.get_busy():
    time.sleep(0.1)

print("OK — se você ouviu a frase, a voz está funcionando.")
try:
    mp3.unlink()
except Exception:
    pass
