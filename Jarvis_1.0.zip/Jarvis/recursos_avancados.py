#!/usr/bin/env python3
"""
Recursos Avançados — Jarvis 1.0
================================
1. Memória de contexto de sessão + resumo automático
2. Confirmação inteligente por voz (ampliada)
3. Rotinas com condições (horário + eventos)
4. Busca semântica na memória + arquivos
5. Modo Foco Profundo (bloqueio de sites + Pomodoro + música)
6. Jarvis no bolso (WhatsApp remoto via Green API)
"""

from __future__ import annotations

import os
import re
import json
import time
import threading
import datetime
import subprocess
import hashlib
from pathlib import Path
from typing import Optional, List, Dict, Any, Callable

_SCRIPT_DIR = Path(__file__).resolve().parent
if (_SCRIPT_DIR / "jarvis.py").exists() or (_SCRIPT_DIR / "memory").exists():
    BASE_DIR = _SCRIPT_DIR
else:
    BASE_DIR = Path.home() / "Jarvis"
MEMORY_DIR = BASE_DIR / "memory"
SESSION_FILE = MEMORY_DIR / "sessao.json"
COND_ROUTINES_FILE = MEMORY_DIR / "rotinas_condicionais.json"
FOCUS_FILE = MEMORY_DIR / "foco_profundo.json"
WHATSAPP_CFG = MEMORY_DIR / "whatsapp_remoto.json"
HOSTS_BACKUP = MEMORY_DIR / "hosts_backup.txt"

DEFAULT_MODEL = os.environ.get("JARVIS_MODEL", "qwen2.5:7b")

# Callbacks injetados
_falar: Callable = print
_processar: Optional[Callable] = None
_console = None
_buscar_vetorial: Optional[Callable] = None
_adicionar_vetorial: Optional[Callable] = None

# Estado
_sessao_lock = threading.Lock()
_foco_ativo = False
_foco_thread: Optional[threading.Thread] = None
_whatsapp_thread: Optional[threading.Thread] = None
_whatsapp_stop = threading.Event()


def configurar(
    falar_fn=None,
    processar_fn=None,
    console=None,
    buscar_vetorial_fn=None,
    adicionar_vetorial_fn=None,
):
    global _falar, _processar, _console, _buscar_vetorial, _adicionar_vetorial
    if falar_fn:
        _falar = falar_fn
    if processar_fn:
        _processar = processar_fn
    if console is not None:
        _console = console
    if buscar_vetorial_fn:
        _buscar_vetorial = buscar_vetorial_fn
    if adicionar_vetorial_fn:
        _adicionar_vetorial = adicionar_vetorial_fn


def _log(msg: str):
    if _console:
        try:
            _console.print(f"[dim][Avançado] {msg}[/]")
            return
        except Exception:
            pass
    print(f"[Avançado] {msg}")


def _ollama(prompt: str, timeout: int = 45) -> str:
    try:
        r = subprocess.run(
            ["ollama", "run", DEFAULT_MODEL, prompt],
            capture_output=True,
            text=True,
            timeout=timeout,
            encoding="utf-8",
            errors="ignore",
        )
        return (r.stdout or "").strip()
    except Exception as e:
        return f"(erro ollama: {e})"


# ============================================================
# 1. MEMÓRIA DE CONTEXTO DE SESSÃO
# ============================================================

def _load_sessao() -> dict:
    if SESSION_FILE.exists():
        try:
            return json.loads(SESSION_FILE.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {
        "inicio": datetime.datetime.now().isoformat(),
        "turnos": [],
        "resumo": "",
        "topicos": [],
    }


def _save_sessao(data: dict):
    MEMORY_DIR.mkdir(parents=True, exist_ok=True)
    SESSION_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def registrar_turno_sessao(usuario: str, jarvis: str):
    """Chamado após cada interação para manter contexto da sessão atual."""
    with _sessao_lock:
        s = _load_sessao()
        s["turnos"].append({
            "usuario": usuario[:500],
            "jarvis": jarvis[:800],
            "hora": datetime.datetime.now().strftime("%H:%M:%S"),
        })
        # Mantém só os últimos 30 turnos em memória quente
        s["turnos"] = s["turnos"][-30:]
        _save_sessao(s)

        # A cada 6 turnos, gera resumo automático
        if len(s["turnos"]) % 6 == 0 and len(s["turnos"]) >= 6:
            threading.Thread(target=_gerar_resumo_sessao, daemon=True).start()


def _gerar_resumo_sessao():
    with _sessao_lock:
        s = _load_sessao()
        if not s.get("turnos"):
            return
        trecho = s["turnos"][-12:]
        texto = "\n".join(
            f"Usuário: {t['usuario']}\nJarvis: {t['jarvis']}" for t in trecho
        )
    prompt = (
        "Resuma a conversa abaixo em 2-4 frases em português, "
        "destacando o que o usuário queria e o que foi decidido/feito. "
        "Seja objetivo.\n\n" + texto[:3500]
    )
    resumo = _ollama(prompt, timeout=40)
    if not resumo or resumo.startswith("(erro"):
        return
    with _sessao_lock:
        s = _load_sessao()
        s["resumo"] = resumo
        # Extrai tópicos simples
        topicos = re.findall(r"\b([A-Za-zÀ-ú]{4,}(?:\s+[A-Za-zÀ-ú]{3,}){0,2})\b", resumo)
        s["topicos"] = list(dict.fromkeys(topicos))[:8]
        _save_sessao(s)
    if _adicionar_vetorial:
        try:
            _adicionar_vetorial(f"Resumo da sessão: {resumo}", {"tipo": "resumo_sessao"})
        except Exception:
            pass
    _log("Resumo de sessão atualizado.")


def obter_contexto_sessao(max_turnos: int = 6) -> str:
    """Retorna texto pronto para injetar no prompt do LLM."""
    s = _load_sessao()
    partes = []
    if s.get("resumo"):
        partes.append(f"Resumo da conversa atual: {s['resumo']}")
    turnos = s.get("turnos", [])[-max_turnos:]
    if turnos:
        linhas = []
        for t in turnos:
            linhas.append(f"- Usuário: {t['usuario'][:120]}")
            linhas.append(f"  Jarvis: {t['jarvis'][:160]}")
        partes.append("Últimos turnos:\n" + "\n".join(linhas))
    return "\n\n".join(partes)


def limpar_sessao():
    with _sessao_lock:
        data = {
            "inicio": datetime.datetime.now().isoformat(),
            "turnos": [],
            "resumo": "",
            "topicos": [],
        }
        _save_sessao(data)
    return "Sessão limpa. Começamos do zero."


def mostrar_resumo_sessao() -> str:
    s = _load_sessao()
    if s.get("resumo"):
        n = len(s.get("turnos", []))
        return f"Resumo da sessão ({n} turnos):\n{s['resumo']}"
    if s.get("turnos"):
        return f"Ainda não tenho resumo automático. Já registramos {len(s['turnos'])} turnos nesta sessão."
    return "Nenhuma conversa nesta sessão ainda."


# ============================================================
# 2. CONFIRMAÇÃO INTELIGENTE (ampliada)
# ============================================================

# Ações que SEMPRE pedem confirmação
ACOES_CRITICAS = {
    "desligar", "reiniciar", "apagar", "deletar", "excluir", "formatar",
    "enviar_whatsapp", "enviar_email", "enviar mensagem", "shutdown",
    "bloquear", "hosts", "foco profundo",
}

PENDING_FILE = MEMORY_DIR / "acao_pendente.json"


def precisa_confirmacao(texto: str) -> bool:
    t = (texto or "").lower()
    return any(a in t for a in ACOES_CRITICAS)


def criar_pendente(acao_id: str, descricao: str, payload: dict | None = None) -> str:
    data = {
        "id": acao_id,
        "descricao": descricao,
        "payload": payload or {},
        "criado": datetime.datetime.now().isoformat(),
        "expira": (datetime.datetime.now() + datetime.timedelta(minutes=2)).isoformat(),
    }
    MEMORY_DIR.mkdir(parents=True, exist_ok=True)
    PENDING_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    return (
        f"Ação sensível detectada: {descricao}. "
        f"Diga 'confirmar' ou 'tem certeza, pode executar' para seguir, "
        f"ou 'cancelar' para desistir. Expira em 2 minutos."
    )


def _pendente_valido() -> dict | None:
    if not PENDING_FILE.exists():
        return None
    try:
        data = json.loads(PENDING_FILE.read_text(encoding="utf-8"))
        exp = data.get("expira")
        if exp and datetime.datetime.fromisoformat(exp) < datetime.datetime.now():
            PENDING_FILE.unlink(missing_ok=True)
            return None
        return data
    except Exception:
        PENDING_FILE.unlink(missing_ok=True)
        return None


def processar_confirmacao(texto: str) -> Optional[str]:
    t = (texto or "").lower().strip()
    afirmacoes = (
        "confirmar", "confirma", "confirmar ação", "confirmar acao",
        "tem certeza pode executar", "pode executar", "sim pode", "executa",
        "pode fazer", "vai em frente", "autorizado",
    )
    negacoes = (
        "cancelar", "cancela", "cancelar ação", "cancelar acao",
        "não", "nao", "desiste", "para", "não executa", "nao executa",
    )

    if any(t == a or t.startswith(a + " ") for a in afirmacoes):
        data = _pendente_valido()
        if not data:
            return "Não há ação pendente para confirmar (ou já expirou)."
        PENDING_FILE.unlink(missing_ok=True)
        return _executar_pendente(data)

    if any(t == n or t.startswith(n + " ") for n in negacoes):
        if PENDING_FILE.exists():
            PENDING_FILE.unlink(missing_ok=True)
            return "Ação cancelada. Nada foi executado."
        return None  # deixa outros handlers tratarem "não"

    return None


def _executar_pendente(data: dict) -> str:
    acao_id = data.get("id", "")
    payload = data.get("payload") or {}

    if acao_id == "desligar":
        os.system("shutdown /s /t 8")
        return "Desligando o PC em 8 segundos."
    if acao_id == "reiniciar":
        os.system("shutdown /r /t 8")
        return "Reiniciando em 8 segundos."
    if acao_id == "apagar_arquivo":
        p = Path(payload.get("caminho", ""))
        if p.exists() and p.is_file():
            p.unlink()
            return f"Arquivo apagado: {p.name}"
        return "Arquivo não encontrado."
    if acao_id == "ativar_foco_profundo":
        return ativar_foco_profundo(
            minutos=int(payload.get("minutos", 25)),
            sites=payload.get("sites"),
        )
    if acao_id == "enviar_whatsapp":
        # Deixa o handler original cuidar se existir
        return f"Confirmação OK para WhatsApp: {payload.get('destino', '')}. (Execute o envio pelo fluxo normal.)"
    if acao_id == "comando_remoto":
        cmd = payload.get("comando", "")
        if _processar and cmd:
            try:
                return str(_processar(cmd))
            except Exception as e:
                return f"Erro ao executar comando remoto: {e}"
        return "Processador de comandos indisponível."

    return f"Ação '{acao_id}' confirmada, mas sem executor específico."


# ============================================================
# 3. ROTINAS COM CONDIÇÕES
# ============================================================

def _load_cond_rotinas() -> list:
    if COND_ROUTINES_FILE.exists():
        try:
            return json.loads(COND_ROUTINES_FILE.read_text(encoding="utf-8"))
        except Exception:
            pass
    return []


def _save_cond_rotinas(lista: list):
    MEMORY_DIR.mkdir(parents=True, exist_ok=True)
    COND_ROUTINES_FILE.write_text(json.dumps(lista, ensure_ascii=False, indent=2), encoding="utf-8")


def adicionar_rotina_condicional(
    nome: str,
    condicao: str,
    comandos: list,
    hora_inicio: str | None = None,
    hora_fim: str | None = None,
) -> str:
    """
    condicao exemplos:
      - "depois_das_22"
      - "antes_das_08"
      - "dia_util"
      - "fim_de_semana"
      - "sempre" (só horário)
    """
    lista = _load_cond_rotinas()
    item = {
        "id": hashlib.md5(f"{nome}{time.time()}".encode()).hexdigest()[:10],
        "nome": nome,
        "condicao": condicao,
        "hora_inicio": hora_inicio,  # "22:00"
        "hora_fim": hora_fim,
        "comandos": comandos if isinstance(comandos, list) else [comandos],
        "ativo": True,
        "ultimo_run": None,
    }
    lista.append(item)
    _save_cond_rotinas(lista)
    extra = ""
    if hora_inicio:
        extra = f" (janela {hora_inicio}" + (f"-{hora_fim}" if hora_fim else "") + ")"
    return f"Rotina condicional '{nome}' criada: condição={condicao}{extra}."


def listar_rotinas_condicionais() -> str:
    lista = _load_cond_rotinas()
    if not lista:
        return "Nenhuma rotina condicional cadastrada."
    linhas = []
    for r in lista:
        st = "ativa" if r.get("ativo") else "pausada"
        cmds = "; ".join(r.get("comandos") or [])
        janela = ""
        if r.get("hora_inicio"):
            janela = f" [{r['hora_inicio']}" + (f"-{r.get('hora_fim', '')}" if r.get("hora_fim") else "") + "]"
        linhas.append(f"- {r['nome']} | {r.get('condicao')}{janela} ({st}): {cmds}")
    return "Rotinas condicionais:\n" + "\n".join(linhas)


def _condicao_ok(r: dict, agora: datetime.datetime) -> bool:
    cond = (r.get("condicao") or "sempre").lower()
    hhmm = agora.strftime("%H:%M")
    weekday = agora.weekday()  # 0=seg ... 6=dom

    # Janela de horário
    hi = r.get("hora_inicio")
    hf = r.get("hora_fim")
    if hi and hf:
        if not (hi <= hhmm <= hf):
            return False
    elif hi:
        if hhmm < hi:
            return False

    if cond in ("sempre", "horario", "horário"):
        return True
    if cond in ("depois_das_22", "apos_22", "noite"):
        return hhmm >= "22:00"
    if cond in ("antes_das_08", "manha_cedo", "cedo"):
        return hhmm < "08:00"
    if cond in ("dia_util", "dias_uteis", "semana"):
        return weekday < 5
    if cond in ("fim_de_semana", "fim de semana", "fds"):
        return weekday >= 5
    if cond.startswith("depois_das_"):
        try:
            h = cond.replace("depois_das_", "")
            if ":" not in h:
                h = f"{int(h):02d}:00"
            return hhmm >= h
        except Exception:
            return False
    if cond.startswith("antes_das_"):
        try:
            h = cond.replace("antes_das_", "")
            if ":" not in h:
                h = f"{int(h):02d}:00"
            return hhmm < h
        except Exception:
            return False
    return False


def thread_rotinas_condicionais():
    while True:
        try:
            agora = datetime.datetime.now()
            hoje = agora.strftime("%Y-%m-%d")
            lista = _load_cond_rotinas()
            mudou = False
            for r in lista:
                if not r.get("ativo"):
                    continue
                if r.get("ultimo_run") == hoje:
                    continue
                if not _condicao_ok(r, agora):
                    continue
                # Só dispara 1x por dia quando a condição fica verdadeira
                _log(f"Rotina condicional: {r.get('nome')}")
                try:
                    _falar(f"Executando rotina {r.get('nome')}")
                except Exception:
                    pass
                for cmd in r.get("comandos") or []:
                    if _processar:
                        try:
                            resp = _processar(cmd)
                            if resp:
                                _falar(str(resp)[:300])
                        except Exception as e:
                            _log(f"erro rotina: {e}")
                r["ultimo_run"] = hoje
                mudou = True
            if mudou:
                _save_cond_rotinas(lista)
        except Exception as e:
            _log(f"thread cond: {e}")
        time.sleep(30)


# ============================================================
# 4. BUSCA SEMÂNTICA NA MEMÓRIA + ARQUIVOS
# ============================================================

def busca_semantica(query: str, n: int = 5) -> str:
    """Busca na memória vetorial + arquivos de conhecimento + sessão."""
    resultados = []

    # 1) Memória vetorial (Chroma)
    if _buscar_vetorial:
        try:
            docs = _buscar_vetorial(query, n=n) or []
            for d in docs:
                if d:
                    resultados.append(("memória", d[:300]))
        except Exception as e:
            _log(f"chroma: {e}")

    # 2) Sessão atual
    s = _load_sessao()
    if s.get("resumo") and query.lower() in s["resumo"].lower():
        resultados.append(("sessão", s["resumo"]))
    for t in reversed(s.get("turnos", [])[-15:]):
        blob = f"{t.get('usuario', '')} {t.get('jarvis', '')}".lower()
        palavras = [p for p in re.findall(r"\w{4,}", query.lower()) if p]
        if palavras and sum(1 for p in palavras if p in blob) >= max(1, len(palavras) // 2):
            resultados.append(("sessão", f"Você: {t['usuario'][:100]} → Jarvis: {t['jarvis'][:120]}"))

    # 3) Arquivos em conhecimento/
    know = BASE_DIR / "conhecimento"
    if know.exists():
        for f in know.glob("*.json"):
            try:
                raw = f.read_text(encoding="utf-8", errors="ignore")
                if any(p in raw.lower() for p in re.findall(r"\w{4,}", query.lower())):
                    resultados.append(("arquivo", f"{f.name}: {raw[:200]}"))
            except Exception:
                pass
        for f in list(know.glob("*.txt")) + list(know.glob("*.md")):
            try:
                raw = f.read_text(encoding="utf-8", errors="ignore")
                if any(p in raw.lower() for p in re.findall(r"\w{4,}", query.lower())):
                    resultados.append(("arquivo", f"{f.name}: {raw[:200]}"))
            except Exception:
                pass

    # 4) memoria.json (fatos + aprendizados)
    mf = MEMORY_DIR / "memoria.json"
    if mf.exists():
        try:
            mem = json.loads(mf.read_text(encoding="utf-8"))
            for item in mem.get("fatos", []) + mem.get("aprendizados", []):
                txt = item.get("texto", "") if isinstance(item, dict) else str(item)
                if any(p in txt.lower() for p in re.findall(r"\w{4,}", query.lower())):
                    resultados.append(("fato", txt[:250]))
        except Exception:
            pass

    if not resultados:
        return f"Não encontrei nada relevante sobre «{query}» na memória ou arquivos."

    # Dedup simples
    vistos = set()
    linhas = []
    for origem, trecho in resultados[:n]:
        key = trecho[:80]
        if key in vistos:
            continue
        vistos.add(key)
        linhas.append(f"[{origem}] {trecho}")

    return f"Resultados para «{query}»:\n" + "\n".join(f"• {l}" for l in linhas)


def o_que_falei_sobre(tema: str) -> str:
    """Atalho amigável: 'o que eu falei sobre X'."""
    return busca_semantica(tema, n=6)


# ============================================================
# 5. MODO FOCO PROFUNDO
# ============================================================

SITES_DISTRACAO_PADRAO = [
    "youtube.com", "www.youtube.com",
    "twitter.com", "x.com", "www.x.com",
    "instagram.com", "www.instagram.com",
    "facebook.com", "www.facebook.com",
    "tiktok.com", "www.tiktok.com",
    "reddit.com", "www.reddit.com",
    "netflix.com", "www.netflix.com",
    "twitch.tv", "www.twitch.tv",
]


def _hosts_path() -> Path:
    return Path(r"C:\Windows\System32\drivers\etc\hosts")


def _bloquear_sites(sites: list) -> bool:
    hosts = _hosts_path()
    try:
        original = hosts.read_text(encoding="utf-8", errors="ignore")
        HOSTS_BACKUP.write_text(original, encoding="utf-8")
        bloco = "\n# --- JARVIS FOCO PROFUNDO ---\n"
        for s in sites:
            bloco += f"127.0.0.1 {s}\n"
            bloco += f"127.0.0.1 www.{s}\n" if not s.startswith("www.") else ""
        bloco += "# --- FIM JARVIS ---\n"
        if "# --- JARVIS FOCO PROFUNDO ---" not in original:
            hosts.write_text(original + bloco, encoding="utf-8")
        # Flush DNS
        subprocess.run(["ipconfig", "/flushdns"], capture_output=True)
        return True
    except PermissionError:
        _log("Sem permissão de admin para editar hosts. Execute o Jarvis como Administrador.")
        return False
    except Exception as e:
        _log(f"hosts: {e}")
        return False


def _desbloquear_sites() -> bool:
    hosts = _hosts_path()
    try:
        if HOSTS_BACKUP.exists():
            hosts.write_text(HOSTS_BACKUP.read_text(encoding="utf-8"), encoding="utf-8")
            HOSTS_BACKUP.unlink(missing_ok=True)
        else:
            txt = hosts.read_text(encoding="utf-8", errors="ignore")
            txt = re.sub(
                r"\n?# --- JARVIS FOCO PROFUNDO ---.*?# --- FIM JARVIS ---\n?",
                "\n",
                txt,
                flags=re.DOTALL,
            )
            hosts.write_text(txt, encoding="utf-8")
        subprocess.run(["ipconfig", "/flushdns"], capture_output=True)
        return True
    except Exception as e:
        _log(f"desbloqueio: {e}")
        return False


def ativar_foco_profundo(minutos: int = 25, sites: list | None = None) -> str:
    global _foco_ativo, _foco_thread
    if _foco_ativo:
        return "Modo foco profundo já está ativo."

    sites = sites or SITES_DISTRACAO_PADRAO
    ok = _bloquear_sites(sites)
    _foco_ativo = True

    data = {
        "ativo": True,
        "inicio": datetime.datetime.now().isoformat(),
        "minutos": minutos,
        "sites": sites,
        "bloqueio_hosts": ok,
    }
    MEMORY_DIR.mkdir(parents=True, exist_ok=True)
    FOCUS_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

    def _timer():
        global _foco_ativo
        time.sleep(max(1, minutos) * 60)
        if _foco_ativo:
            desativar_foco_profundo(aviso=True)

    _foco_thread = threading.Thread(target=_timer, daemon=True)
    _foco_thread.start()

    msg = f"Modo Foco Profundo ativado por {minutos} minutos."
    if ok:
        msg += " Sites de distração bloqueados."
    else:
        msg += " (Não consegui editar o hosts — rode como Administrador para bloquear sites.)"
    msg += " Bom foco. Diga 'sair do foco' para encerrar antes."
    return msg


def desativar_foco_profundo(aviso: bool = False) -> str:
    global _foco_ativo
    _foco_ativo = False
    _desbloquear_sites()
    if FOCUS_FILE.exists():
        try:
            data = json.loads(FOCUS_FILE.read_text(encoding="utf-8"))
            data["ativo"] = False
            data["fim"] = datetime.datetime.now().isoformat()
            FOCUS_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception:
            FOCUS_FILE.unlink(missing_ok=True)

    msg = "Modo Foco Profundo encerrado. Sites liberados."
    if aviso:
        try:
            _falar("Tempo de foco esgotado. Bom trabalho!")
        except Exception:
            pass
    return msg


def status_foco() -> str:
    if not _foco_ativo:
        return "Modo foco profundo está desligado."
    try:
        data = json.loads(FOCUS_FILE.read_text(encoding="utf-8"))
        inicio = data.get("inicio", "")[:16].replace("T", " ")
        return f"Foco ativo desde {inicio} ({data.get('minutos', '?')} min planejados)."
    except Exception:
        return "Foco ativo."


# ============================================================
# 6. JARVIS NO BOLSO — WHATSAPP (Green API)
# ============================================================
# Por que Green API?
# - pywhatkit só ENVIA mensagens (não escuta)
# - WhatsApp Web + Selenium quebra fácil e viola ToS
# - Green API oferece receiveNotification + sendMessage via HTTP
#   (plano gratuito para uso pessoal: https://green-api.com)
#
# Config:
#   memory/whatsapp_remoto.json
#   {
#     "id_instance": "1101xxxxxxx",
#     "api_token": "xxxxxxxx",
#     "api_url": "https://api.green-api.com",
#     "allowed_phones": ["5511999998888"],
#     "ativo": true
#   }

def _load_whatsapp_cfg() -> dict:
    if WHATSAPP_CFG.exists():
        try:
            return json.loads(WHATSAPP_CFG.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {
        "id_instance": "",
        "api_token": "",
        "api_url": "https://api.green-api.com",
        "allowed_phones": [],
        "ativo": False,
    }


def _save_whatsapp_cfg(cfg: dict):
    MEMORY_DIR.mkdir(parents=True, exist_ok=True)
    WHATSAPP_CFG.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")


def _normalizar_telefone(num: str) -> str:
    digitos = "".join(c for c in str(num) if c.isdigit())
    # Remove zeros à esquerda de códigos estranhos; mantém DDI
    return digitos


def configurar_whatsapp(id_instance: str, api_token: str, telefone: str | None = None) -> str:
    cfg = _load_whatsapp_cfg()
    cfg["id_instance"] = id_instance.strip()
    cfg["api_token"] = api_token.strip()
    cfg["api_url"] = cfg.get("api_url") or "https://api.green-api.com"
    if telefone:
        phone = _normalizar_telefone(telefone)
        phones = cfg.get("allowed_phones") or []
        if phone and phone not in phones:
            phones.append(phone)
        cfg["allowed_phones"] = phones
    cfg["ativo"] = True
    _save_whatsapp_cfg(cfg)
    extra = ""
    if telefone:
        extra = f" Número autorizado: {_normalizar_telefone(telefone)}."
    return (
        "WhatsApp remoto configurado (Green API)."
        f"{extra} "
        "Diga 'iniciar whatsapp' ou 'jarvis no bolso' para começar a escutar. "
        "Só números em allowed_phones controlam o PC."
    )


def autorizar_whatsapp(telefone: str) -> str:
    cfg = _load_whatsapp_cfg()
    phone = _normalizar_telefone(telefone)
    if not phone or len(phone) < 10:
        return "Informe o número com DDI, ex: 5511999998888"
    phones = cfg.get("allowed_phones") or []
    if phone not in phones:
        phones.append(phone)
    cfg["allowed_phones"] = phones
    _save_whatsapp_cfg(cfg)
    return f"Número {phone} autorizado a controlar o Jarvis pelo WhatsApp."


def _wa_base(cfg: dict) -> str:
    api = (cfg.get("api_url") or "https://api.green-api.com").rstrip("/")
    inst = cfg.get("id_instance", "")
    tok = cfg.get("api_token", "")
    return f"{api}/waInstance{inst}", tok


def _enviar_whatsapp_api(cfg: dict, chat_id: str, texto: str) -> bool:
    """chat_id Green API: 5511999998888@c.us"""
    try:
        import urllib.request
        base, tok = _wa_base(cfg)
        url = f"{base}/sendMessage/{tok}"
        body = json.dumps({
            "chatId": chat_id,
            "message": (texto or "")[:3500],
        }).encode("utf-8")
        req = urllib.request.Request(
            url,
            data=body,
            method="POST",
            headers={"Content-Type": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=20) as resp:
            return resp.status == 200
    except Exception as e:
        _log(f"send whatsapp: {e}")
        return False


def _receber_notificacao(cfg: dict) -> dict | None:
    try:
        import urllib.request
        base, tok = _wa_base(cfg)
        url = f"{base}/receiveNotification/{tok}?receiveTimeout=20"
        with urllib.request.urlopen(url, timeout=30) as resp:
            raw = resp.read().decode("utf-8")
            if not raw or raw.strip() in ("null", ""):
                return None
            return json.loads(raw)
    except Exception as e:
        # timeout normal em long-poll vazio
        if "timed out" not in str(e).lower():
            _log(f"receive wa: {e}")
        return None


def _apagar_notificacao(cfg: dict, receipt_id) -> None:
    try:
        import urllib.request
        base, tok = _wa_base(cfg)
        url = f"{base}/deleteNotification/{tok}/{receipt_id}"
        req = urllib.request.Request(url, method="DELETE")
        urllib.request.urlopen(req, timeout=10)
    except Exception:
        pass


def _extrair_mensagem_wa(body: dict) -> tuple[str, str, str]:
    """
    Retorna (chat_id, phone_digits, texto)
    Formatos Green API: incomingMessageReceived
    """
    try:
        type_webhook = body.get("typeWebhook") or ""
        if type_webhook != "incomingMessageReceived":
            return "", "", ""
        sender = body.get("senderData") or {}
        chat_id = sender.get("chatId") or body.get("chatId") or ""
        phone = _normalizar_telefone(chat_id.split("@")[0] if chat_id else "")
        msg_data = body.get("messageData") or {}
        tipo = msg_data.get("typeMessage") or ""
        texto = ""
        if tipo == "textMessage":
            texto = (msg_data.get("textMessageData") or {}).get("textMessage") or ""
        elif tipo == "extendedTextMessage":
            texto = (msg_data.get("extendedTextMessageData") or {}).get("text") or ""
        else:
            # tenta campos comuns
            texto = (
                (msg_data.get("textMessageData") or {}).get("textMessage")
                or (msg_data.get("extendedTextMessageData") or {}).get("text")
                or ""
            )
        return chat_id, phone, (texto or "").strip()
    except Exception:
        return "", "", ""


def _whatsapp_loop():
    cfg = _load_whatsapp_cfg()
    if not cfg.get("id_instance") or not cfg.get("api_token"):
        _log("WhatsApp: credenciais ausentes")
        return
    _log("WhatsApp remoto iniciado (Green API poll)")

    while not _whatsapp_stop.is_set():
        try:
            cfg = _load_whatsapp_cfg()  # recarrega autorizações
            notif = _receber_notificacao(cfg)
            if not notif:
                time.sleep(1)
                continue

            receipt_id = notif.get("receiptId")
            body = notif.get("body") or notif
            chat_id, phone, texto = _extrair_mensagem_wa(body if isinstance(body, dict) else {})

            # Sempre apaga a notificação para não reprocessar
            if receipt_id is not None:
                _apagar_notificacao(cfg, receipt_id)

            if not texto or not chat_id:
                continue

            allowed = [_normalizar_telefone(p) for p in (cfg.get("allowed_phones") or [])]

            # Primeiro contato: se lista vazia, autoriza automaticamente
            if not allowed and phone:
                cfg["allowed_phones"] = [phone]
                _save_whatsapp_cfg(cfg)
                allowed = [phone]
                _enviar_whatsapp_api(
                    cfg, chat_id,
                    f"Jarvis: número {phone} autorizado automaticamente. "
                    "Envie comandos como se falasse comigo."
                )

            if phone not in allowed:
                _enviar_whatsapp_api(cfg, chat_id, "Acesso negado. Este número não está autorizado.")
                continue

            # Atalhos de ajuda
            low = texto.lower().strip()
            if low in ("ajuda", "help", "/help", "oi jarvis", "olá jarvis", "ola jarvis"):
                _enviar_whatsapp_api(
                    cfg, chat_id,
                    "Jarvis no bolso (WhatsApp) ativo.\n"
                    "Envie qualquer comando:\n"
                    "• que horas são\n"
                    "• abre o chrome\n"
                    "• resumo do dia\n"
                    "• status foco\n"
                    "• o que eu falei sobre X"
                )
                continue

            # Comandos sensíveis → confirmação no PC
            if precisa_confirmacao(texto):
                criar_pendente(
                    "comando_remoto",
                    f"Comando remoto do WhatsApp ({phone}): {texto}",
                    {"comando": texto, "chat_id": chat_id, "phone": phone},
                )
                _enviar_whatsapp_api(
                    cfg, chat_id,
                    "Comando sensível. Confirme no PC dizendo 'confirmar'."
                )
                try:
                    _falar(f"Pedido remoto pelo WhatsApp: {texto}. Confirme se deseja executar.")
                except Exception:
                    pass
                continue

            if _processar:
                try:
                    resp = _processar(texto)
                    ok = _enviar_whatsapp_api(cfg, chat_id, str(resp)[:3500] if resp else "OK")
                    if not ok:
                        _log("Falha ao responder no WhatsApp")
                except Exception as e:
                    _enviar_whatsapp_api(cfg, chat_id, f"Erro: {e}")
            else:
                _enviar_whatsapp_api(cfg, chat_id, "Processador de comandos não está ligado.")

        except Exception as e:
            _log(f"whatsapp loop: {e}")
            time.sleep(5)


def iniciar_whatsapp() -> str:
    global _whatsapp_thread
    cfg = _load_whatsapp_cfg()
    if not cfg.get("id_instance") or not cfg.get("api_token"):
        return (
            "WhatsApp remoto não configurado.\n"
            "1) Crie conta gratuita em https://green-api.com\n"
            "2) Crie uma instância e escaneie o QR com o WhatsApp do celular\n"
            "3) Copie idInstance e apiToken\n"
            "4) Diga: configurar whatsapp ID_INSTANCE API_TOKEN\n"
            "5) Opcional: autorizar whatsapp 5511999998888\n"
            "6) Depois: iniciar whatsapp"
        )
    if _whatsapp_thread and _whatsapp_thread.is_alive():
        return "WhatsApp remoto já está rodando."
    _whatsapp_stop.clear()
    cfg["ativo"] = True
    _save_whatsapp_cfg(cfg)
    _whatsapp_thread = threading.Thread(target=_whatsapp_loop, daemon=True)
    _whatsapp_thread.start()
    phones = cfg.get("allowed_phones") or []
    extra = f" Números autorizados: {', '.join(phones)}." if phones else " O primeiro número que mandar mensagem será autorizado."
    return f"Jarvis no bolso (WhatsApp) iniciado.{extra}"


def parar_whatsapp() -> str:
    _whatsapp_stop.set()
    cfg = _load_whatsapp_cfg()
    cfg["ativo"] = False
    _save_whatsapp_cfg(cfg)
    return "WhatsApp remoto parado."


def status_whatsapp() -> str:
    cfg = _load_whatsapp_cfg()
    if not cfg.get("id_instance"):
        return "WhatsApp remoto não configurado."
    rodando = _whatsapp_thread is not None and _whatsapp_thread.is_alive()
    return (
        f"WhatsApp remoto: instance={cfg.get('id_instance')} | "
        f"ativo={cfg.get('ativo')} | thread={'rodando' if rodando else 'parada'} | "
        f"autorizados={cfg.get('allowed_phones')}"
    )



# ============================================================
# PROCESSADOR DE COMANDOS DESTE MÓDULO
# ============================================================

def processar_avancados(texto: str) -> Optional[str]:
    t = (texto or "").lower().strip()
    if not t:
        return None

    # --- Confirmação ---
    resp = processar_confirmacao(texto)
    if resp is not None:
        return resp

    # --- Sessão ---
    if any(x in t for x in (
        "resumo da sessão", "resumo da sessao", "resumo dessa conversa",
        "do que estávamos falando", "do que estavamos falando", "contexto atual",
    )):
        return mostrar_resumo_sessao()
    if any(x in t for x in ("limpar sessão", "limpar sessao", "nova sessão", "nova sessao", "esquecer conversa")):
        return limpar_sessao()

    # --- Busca semântica ---
    m = re.search(
        r"(?:o que (?:eu|nós|nos) (?:falei|falamos|disse|dissemos) sobre|busca(?:r)? na memória|busca(?:r)? na memoria|procure na memória|procure na memoria|o que você lembra sobre|o que voce lembra sobre)\s+(.+)",
        t,
    )
    if m:
        return o_que_falei_sobre(m.group(1).strip(" ?.!"))
    m = re.search(r"(?:busca semântica|busca semantica|pesquisa memória|pesquisa memoria)\s+(.+)", t)
    if m:
        return busca_semantica(m.group(1).strip())

    # --- Foco profundo ---
    if any(x in t for x in (
        "foco profundo", "modo foco profundo", "ativa foco profundo",
        "bloquear distrações", "bloquear distracoes", "bloqueia sites",
    )):
        m = re.search(r"(\d+)\s*minutos?", t)
        minutos = int(m.group(1)) if m else 25
        # Ações que mexem no hosts pedem confirmação
        return criar_pendente(
            "ativar_foco_profundo",
            f"Ativar Foco Profundo por {minutos} minutos (bloqueia YouTube, redes etc.)",
            {"minutos": minutos},
        )
    if any(x in t for x in (
        "sair do foco", "desativa foco profundo", "encerra foco", "desbloquear sites",
        "desbloqueia sites", "cancela foco profundo",
    )):
        return desativar_foco_profundo()
    if any(x in t for x in ("status foco", "foco está ativo", "foco esta ativo", "está em foco", "esta em foco")):
        return status_foco()

    # --- Rotinas condicionais ---
    if any(x in t for x in (
        "listar rotinas condicionais", "rotinas condicionais", "minhas rotinas condicionais",
    )):
        return listar_rotinas_condicionais()

    # "se eu chegar depois das 22 avisa ..." / "cria rotina se depois das 22 ..."
    m = re.search(
        r"(?:cria(?:r)? rotina condicional|nova rotina condicional|se (?:eu )?(.+?))\s+"
        r"(?:depois das|após as|apos as|antes das)\s*(\d{1,2})(?::(\d{2}))?\s*"
        r"(?:avisa|executa|faz|para)\s+(.+)",
        t,
    )
    if m:
        # Forma: se ... depois das 22 ... faz X
        pass  # coberto pelo próximo

    m = re.search(
        r"(?:cria(?:r)? rotina condicional|rotina se)\s+(.+?)\s+"
        r"(depois das|antes das|dia útil|dia util|fim de semana)\s*"
        r"(?:(\d{1,2})(?::(\d{2}))?)?\s*"
        r"(?:para|faz|executa|avisa)?\s*(.+)?",
        t,
    )
    if m:
        nome = m.group(1).strip()
        tipo = m.group(2).strip()
        h = m.group(3)
        mi = m.group(4)
        cmds_raw = (m.group(5) or "me avisa").strip()
        if "depois" in tipo:
            cond = f"depois_das_{int(h or 22):02d}:{int(mi or 0):02d}"
            hi = f"{int(h or 22):02d}:{int(mi or 0):02d}"
        elif "antes" in tipo:
            cond = f"antes_das_{int(h or 8):02d}:{int(mi or 0):02d}"
            hi = None
        elif "fim" in tipo:
            cond = "fim_de_semana"
            hi = None
        else:
            cond = "dia_util"
            hi = None
        comandos = [c.strip() for c in re.split(r",| e depois | depois ", cmds_raw) if c.strip()]
        return adicionar_rotina_condicional(nome, cond, comandos, hora_inicio=hi)

    # Atalho natural: "se passar das 22 avisa minha esposa"
    m = re.search(
        r"se (?:eu )?(?:chegar|passar|ficar)(?: em casa)?(?: depois| após| apos)?(?: das| as)?\s*"
        r"(\d{1,2})(?::(\d{2}))?\s*(?:h|hrs|horas)?\s*(?:avisa|manda mensagem|notifica)\s+(.+)",
        t,
    )
    if m:
        h = int(m.group(1))
        mi = int(m.group(2) or 0)
        alvo = m.group(3).strip()
        cond = f"depois_das_{h:02d}:{mi:02d}"
        cmd = f"me avisa: horário limite — {alvo}"
        return adicionar_rotina_condicional(
            f"Aviso após {h:02d}:{mi:02d}",
            cond,
            [cmd],
            hora_inicio=f"{h:02d}:{mi:02d}",
        )

    # --- WhatsApp remoto (Jarvis no bolso) ---
    m = re.search(
        r"configurar whatsapp\s+(\S+)\s+(\S+)(?:\s+(\+?\d{10,15}))?",
        t,
    )
    if m:
        return configurar_whatsapp(m.group(1), m.group(2), m.group(3))
    m = re.search(r"autorizar whatsapp\s+(\+?\d{10,15})", t)
    if m:
        return autorizar_whatsapp(m.group(1))
    if any(x in t for x in (
        "iniciar whatsapp", "liga whatsapp", "ativa whatsapp",
        "jarvis no bolso", "whatsapp remoto",
    )):
        return iniciar_whatsapp()
    if any(x in t for x in (
        "parar whatsapp", "desliga whatsapp", "desativa whatsapp", "parar whatsapp remoto",
    )):
        return parar_whatsapp()
    if t in ("status whatsapp", "whatsapp status", "status whatsapp remoto"):
        return status_whatsapp()

    return None


def iniciar_servicos_avancados(
    falar_fn=None,
    processar_fn=None,
    console=None,
    buscar_vetorial_fn=None,
    adicionar_vetorial_fn=None,
    auto_whatsapp: bool = True,
):
    configurar(
        falar_fn=falar_fn,
        processar_fn=processar_fn,
        console=console,
        buscar_vetorial_fn=buscar_vetorial_fn,
        adicionar_vetorial_fn=adicionar_vetorial_fn,
    )
    threading.Thread(target=thread_rotinas_condicionais, daemon=True).start()
    cfg = _load_whatsapp_cfg()
    if auto_whatsapp and cfg.get("id_instance") and cfg.get("api_token") and cfg.get("ativo"):
        iniciar_whatsapp()
    _log("Serviços avançados iniciados (sessão, rotinas condicionais, whatsapp opcional)")
