' Inicia o Jarvis 1.0 sem janela de console (bom para bandeja / início automático)
Set WshShell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
pasta = fso.GetParentFolderName(WScript.ScriptFullName)
WshShell.CurrentDirectory = pasta

' Tenta py launcher, depois python
pythonCmd = "python"
On Error Resume Next
WshShell.Run "py -3 --version", 0, True
If Err.Number = 0 Then
  pythonCmd = "py -3"
End If
On Error GoTo 0

WshShell.Run pythonCmd & " """ & pasta & "\jarvis.py""", 0, False
