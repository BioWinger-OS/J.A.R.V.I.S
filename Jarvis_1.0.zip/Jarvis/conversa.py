#!/usr/bin/env python3
"""
Jarvis — Modo Somente Conversa
==============================
Carrega memória, conhecimento JSON, aprendizados e conversa por voz
em velocidade natural (sem comandos de sistema).

Uso:
  python conversa.py
  python conversa.py --texto          # só teclado
  python conversa.py --voz antonio    # tenta voz pt-BR no Windows
"""

import os
import sys
import json
import time
import argparse
import datetime
import subprocess
import tempfile
from pathlib import Path

_SCRIPT_DIR = Path(__file__).resolve().parent
if (_SCRIPT_DIR / "jarvis.py").exists() or (_SCRIPT_DIR / "memory").exists():
    BASE_DIR = _SCRIPT_DIR
else:
    BASE_DIR = Path.home() / "Jarvis"
MEMORY_DIR = BASE_DIR / "memory"
KNOWLEDGE_DIR = BASE_DIR / "conhecimento"
VOICE_DIR = BASE_DIR / "voices"

MEMORY_FILE = MEMORY_DIR / "memoria.json"
CHROMA_DIR = MEMORY_DIR / "chroma_db"

DEFAULT_MODEL = os.environ.get("JARVIS_MODEL", "qwen2.5:7b")
WAKE_WORDS = ("jarvis", "ei jarvis", "ok jarvis", "hey jarvis")

# Velocidade natural da fala (pyttsx3: ~150-170 é conversa normal)
SPEECH_RATE = 155
SPEECH_VOLUME = 0.95


# ------------------------------------------------------------
# Carregar tudo que o Jarvis "sabe"
# ------------------------------------------------------------

def carregar_memoria():
    if MEMORY_FILE.exists():
        try:
            with open(MEMORY_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return {"fatos": [], "preferencias": {}, "historico": [], "aprendizados": [], "perfil": {}}


def carregar_conhecimento_json():
    itens = []
    if not KNOWLEDGE_DIR.exists():
        return itens
    for arq in sorted(KNOWLEDGE_DIR.glob("*.json")):
        try:
            data = json.loads(arq.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                titulo = data.get("titulo") or data.get("title") or arq.stem
                conteudo = data.get("conteudo") or data.get("content") or data.get("texto") or str(data)
                if not isinstance(conteudo, str):
                    conteudo = json.dumps(conteudo, ensure_ascii=False)
                itens.append({"titulo": titulo, "conteudo": conteudo[:2000]})
            elif isinstance(data, list):
                itens.append({"titulo": arq.stem, "conteudo": "\n".join(str(x) for x in data)[:2000]})
        except Exception:
            continue
    return itens


def buscar_memoria_vetorial(query, n=4):
    try:
        import chromadb
        client = chromadb.PersistentClient(path=str(CHROMA_DIR))
        col = client.get_or_create_collection("jarvis_memory")
        r = col.query(query_texts=[query], n_results=n)
        return r.get("documents", [[]])[0]
    except Exception:
        return []


def montar_contexto(pergunta=""):
    """Junta memória + JSON + vetorial para o modelo 'ler' antes de falar."""
    mem = carregar_memoria()
    partes = []

    perfil = mem.get("perfil") or {}
    if perfil:
        partes.append("Perfil do usuário:")
        for k, v in perfil.items():
            partes.append(f"- {k}: {v}")

    fatos = mem.get("fatos") or []
    if fatos:
        partes.append("\nFatos conhecidos:")
        for f in fatos[-20:]:
            t = f.get("texto", f) if isinstance(f, dict) else str(f)
            partes.append(f"- {t}")

    aprend = mem.get("aprendizados") or []
    if aprend:
        partes.append("\nAprendizados recentes:")
        for a in aprend[-12:]:
            t = a.get("texto", a) if isinstance(a, dict) else str(a)
            partes.append(f"- {t}")

    prefs = mem.get("preferencias") or {}
    if prefs:
        partes.append("\nPreferências:")
        for k, v in prefs.items():
            partes.append(f"- {k}: {v}")

    # Correções de fala (se existirem)
    correcoes = mem.get("correcoes_stt") or mem.get("correcoes") or []
    if correcoes:
        partes.append("\nCorreções de fala do usuário (respeite os termos corretos):")
        for c in correcoes[-15:]:
            if isinstance(c, dict):
                partes.append(f"- quando disser '{c.get('errado', '')}' significa '{c.get('correto', '')}'")

    # Arquivos JSON de conhecimento
    conhecimentos = carregar_conhecimento_json()
    if conhecimentos:
        partes.append("\nConhecimento em arquivos:")
        for item in conhecimentos[-10:]:
            partes.append(f"\n[{item['titulo']}]\n{item['conteudo'][:1200]}")

    # Memória vetorial relacionada à pergunta
    if pergunta:
        vet = buscar_memoria_vetorial(pergunta, n=4)
        if vet:
            partes.append("\nMemórias relacionadas a esta pergunta:")
            for v in vet:
                partes.append(f"- {v[:400]}")

    # Histórico recente (últimas falas)
    hist = mem.get("historico") or []
    if hist:
        partes.append("\nÚltimas conversas:")
        for h in hist[-6:]:
            u = (h.get("usuario") or "")[:120]
            j = (h.get("jarvis") or "")[:200]
            partes.append(f"Usuário: {u}")
            partes.append(f"Jarvis: {j}")

    return "\n".join(partes) if partes else "Ainda há pouco contexto salvo sobre o usuário."


def salvar_turno(usuario, jarvis):
    mem = carregar_memoria()
    hist = mem.setdefault("historico", [])
    hist.append({
        "usuario": usuario,
        "jarvis": jarvis,
        "data": datetime.datetime.now().isoformat(),
        "modo": "conversa",
    })
    mem["historico"] = hist[-80:]
    MEMORY_DIR.mkdir(parents=True, exist_ok=True)
    MEMORY_FILE.write_text(json.dumps(mem, ensure_ascii=False, indent=2), encoding="utf-8")

    # também na memória vetorial, se existir
    try:
        import chromadb, uuid
        client = chromadb.PersistentClient(path=str(CHROMA_DIR))
        col = client.get_or_create_collection("jarvis_memory")
        col.add(
            documents=[f"Usuário: {usuario} | Jarvis: {jarvis}"],
            metadatas=[{"tipo": "conversa", "data": datetime.datetime.now().isoformat()}],
            ids=[str(uuid.uuid4())],
        )
    except Exception:
        pass


# ------------------------------------------------------------
# Cérebro (Ollama)
# ------------------------------------------------------------

def perguntar(pergunta, historico_sessao):
    contexto = montar_contexto(pergunta)
    hist_txt = ""
    for u, j in historico_sessao[-6:]:
        hist_txt += f"Usuário: {u}\nJarvis: {j}\n"

    prompt = f"""Você é o J.A.R.V.I.S., assistente pessoal em conversa natural.
Responda SEMPRE em português brasileiro.
Fale como em uma conversa real: claro, educado, humano, sem listas longas demais.
Velocidade mental: respostas médias (2 a 5 frases), a menos que o usuário peça detalhe.
Não invente fatos sobre o usuário; use o contexto abaixo.
Não execute comandos de computador — só converse.

=== O QUE VOCÊ SABE ===
{contexto}
=== FIM DO CONTEXTO ===

{hist_txt}Usuário: {pergunta}
Jarvis:"""

    try:
        r = subprocess.run(
            ["ollama", "run", DEFAULT_MODEL, prompt],
            capture_output=True, text=True, timeout=120,
            encoding="utf-8", errors="ignore",
        )
        resp = (r.stdout or "").strip()
        if "Jarvis:" in resp:
            resp = resp.split("Jarvis:")[-1].strip()
        # limpa artefatos comuns
        resp = resp.replace("===", "").strip()
        return resp or "Não consegui formular uma resposta agora."
    except subprocess.TimeoutExpired:
        return "Desculpe, demorei demais para pensar."
    except Exception as e:
        return f"Erro ao consultar o modelo: {e}"


# ------------------------------------------------------------
# Voz — TTS em velocidade natural
# ------------------------------------------------------------

_tts = None


def init_tts(voz_preferida=None):
    global _tts
    import pyttsx3
    _tts = pyttsx3.init()
    _tts.setProperty("rate", SPEECH_RATE)
    _tts.setProperty("volume", SPEECH_VOLUME)

    voices = _tts.getProperty("voices") or []
    escolhida = None
    prefer = (voz_preferida or "").lower()

    for v in voices:
        nome = f"{getattr(v, 'name', '')} {getattr(v, 'id', '')}".lower()
        if prefer and prefer in nome:
            escolhida = v.id
            break
        if any(x in nome for x in ("portuguese", "brazil", "pt-br", "maria", "francisca", "antonio", "daniel")):
            escolhida = v.id
            # não break — continua se houver match mais específico com prefer

    if prefer:
        for v in voices:
            nome = f"{getattr(v, 'name', '')} {getattr(v, 'id', '')}".lower()
            if prefer in nome:
                escolhida = v.id
                break

    if escolhida:
        _tts.setProperty("voice", escolhida)

    return _tts


def falar(texto):
    """Fala em ritmo natural, frase a frase (soa mais humano)."""
    global _tts
    print(f"\nJarvis: {texto}\n")
    if _tts is None:
        init_tts()

    # Parte em frases para pausas naturais
    import re
    frases = re.split(r"(?<=[.!?…])\s+", texto.strip())
    frases = [f.strip() for f in frases if f.strip()]
    if not frases:
        frases = [texto]

    for frase in frases:
        try:
            _tts.say(frase)
            _tts.runAndWait()
            time.sleep(0.12)  # pausa curta entre frases
        except Exception:
            # reinicia engine se travar
            try:
                init_tts()
                _tts.say(frase)
                _tts.runAndWait()
            except Exception as e:
                print(f"[TTS] {e}")


# ------------------------------------------------------------
# Escuta — STT
# ------------------------------------------------------------

def ouvir_whisper(timeout=8):
    try:
        import sounddevice as sd
        from scipy.io.wavfile import write
        from faster_whisper import WhisperModel

        print("Ouvindo...", flush=True)
        fs = 16000
        audio = sd.rec(int(timeout * fs), samplerate=fs, channels=1, dtype="float32")
        sd.wait()

        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp:
            path = tmp.name
            write(path, fs, (audio * 32767).astype("int16"))

        device = os.environ.get("JARVIS_WHISPER_DEVICE", "cpu")
        model = WhisperModel("base", device=device, compute_type="int8")
        segments, _ = model.transcribe(path, language="pt")
        texto = " ".join(s.text for s in segments).strip()
        try:
            os.unlink(path)
        except Exception:
            pass
        return texto
    except Exception as e:
        print(f"[STT Whisper] {e}")
        return ""


def ouvir_vosk(timeout=7):
    try:
        import sounddevice as sd
        from vosk import Model, KaldiRecognizer

        model_path = BASE_DIR / "vosk-model"
        if not model_path.exists():
            for p in (BASE_DIR / "vosk-model-small-pt", BASE_DIR / "model"):
                if p.exists():
                    model_path = p
                    break
        if not model_path.exists():
            print("Modelo Vosk não encontrado.")
            return ""

        rec = KaldiRecognizer(Model(str(model_path)), 16000)
        print("Ouvindo...", flush=True)
        audio = sd.rec(int(timeout * 16000), samplerate=16000, channels=1, dtype="int16")
        sd.wait()
        rec.AcceptWaveform(audio.tobytes())
        import json as _json
        texto = _json.loads(rec.FinalResult()).get("text", "").strip()
        return texto
    except Exception as e:
        print(f"[STT Vosk] {e}")
        return ""


def ouvir():
    engine = os.environ.get("JARVIS_STT", "whisper").lower()
    if engine == "vosk":
        return ouvir_vosk()
    texto = ouvir_whisper()
    if not texto:
        return ouvir_vosk()
    return texto


def limpar_wake(texto):
    t = texto.strip()
    low = t.lower()
    for w in WAKE_WORDS:
        if low.startswith(w):
            return t[len(w):].strip()
    return t


# ------------------------------------------------------------
# Main
# ------------------------------------------------------------

def main():
    global SPEECH_RATE
    parser = argparse.ArgumentParser(description="Jarvis — somente conversa")
    parser.add_argument("--texto", action="store_true", help="Usar teclado em vez de microfone")
    parser.add_argument("--voz", default="", help="Nome parcial da voz TTS (ex: antonio, maria)")
    parser.add_argument("--rate", type=int, default=SPEECH_RATE, help="Velocidade da fala (padrão 155)")
    args = parser.parse_args()

    SPEECH_RATE = args.rate

    print("=" * 50)
    print("  JARVIS — Modo Somente Conversa")
    print("=" * 50)

    # Pré-carrega contexto para mostrar o que ele "leu"
    ctx = montar_contexto()
    n_json = len(carregar_conhecimento_json())
    mem = carregar_memoria()
    print(f"Modelo: {DEFAULT_MODEL}")
    print(f"Fatos: {len(mem.get('fatos') or [])} | Aprendizados: {len(mem.get('aprendizados') or [])}")
    print(f"Arquivos de conhecimento: {n_json}")
    print(f"Velocidade da fala: {SPEECH_RATE}")
    print("-" * 50)
    print("Comandos: 'sair' / 'tchau' para encerrar | 'contexto' para ver o que ele sabe")
    print()

    init_tts(args.voz or None)

    # Cumprimento
    hora = datetime.datetime.now().hour
    if 5 <= hora < 12:
        saudacao = "Bom dia. Estou em modo conversa, com tudo que já sei sobre você carregado."
    elif 12 <= hora < 18:
        saudacao = "Boa tarde. Modo conversa ativo. Pode falar comigo normalmente."
    else:
        saudacao = "Boa noite. Modo conversa ativo. Estou ouvindo."

    falar(saudacao)

    historico_sessao = []

    while True:
        try:
            if args.texto:
                bruto = input("Você: ").strip()
            else:
                bruto = ouvir()
                if bruto:
                    print(f"Você: {bruto}")

            if not bruto:
                continue

            texto = limpar_wake(bruto)
            low = texto.lower().strip()

            if low in ("sair", "tchau", "encerrar", "desligar", "exit", "quit"):
                falar("Até logo. Foi bom conversar.")
                break

            if low in ("contexto", "o que você sabe", "o que voce sabe"):
                resumo = montar_contexto()[:800]
                falar("Isso é um resumo do que tenho na memória.")
                print(resumo)
                continue

            if low in ("mais devagar", "fala mais devagar"):
                SPEECH_RATE = max(120, SPEECH_RATE - 15)
                init_tts(args.voz or None)
                falar("Tudo bem. Vou falar um pouco mais devagar.")
                continue

            if low in ("mais rapido", "mais rápido", "fala mais rápido", "fala mais rapido"):
                SPEECH_RATE = min(190, SPEECH_RATE + 15)
                init_tts(args.voz or None)
                falar("Certo. Acelerando um pouco.")
                continue

            resposta = perguntar(texto, historico_sessao)
            falar(resposta)

            historico_sessao.append((texto, resposta))
            historico_sessao = historico_sessao[-20:]
            salvar_turno(texto, resposta)

        except KeyboardInterrupt:
            print()
            falar("Encerrando a conversa.")
            break
        except Exception as e:
            print(f"[Erro] {e}")
            time.sleep(0.5)


if __name__ == "__main__":
    main()
