#!/usr/bin/env python3
"""
Bandeja do sistema + início com o Windows — Jarvis 1.0
======================================================
- Ícone perto do relógio (bandeja)
- Menu: Ouvir / Modo texto / Status / Iniciar com Windows / Sair
- Registro no Startup do Windows (pasta Inicializar ou atalho)
"""

from __future__ import annotations

import os
import sys
import json
import threading
import subprocess
from pathlib import Path
from typing import Optional, Callable

BASE_DIR = Path(__file__).resolve().parent
if not (BASE_DIR / "jarvis.py").exists():
    BASE_DIR = Path.home() / "Jarvis"

MEMORY_DIR = BASE_DIR / "memory"
CONFIG_FILE = MEMORY_DIR / "bandeja_config.json"
STARTUP_NAME = "Jarvis 1.0"

_falar: Optional[Callable] = None
_processar: Optional[Callable] = None
_console = None
_set_modo_texto: Optional[Callable] = None
_get_modo_texto: Optional[Callable] = None
_pedir_parar: Optional[Callable] = None
_icon = None
_tray_thread: Optional[threading.Thread] = None
_tray_started = False
_status_msg = "Online"


def configurar(
    falar_fn=None,
    processar_fn=None,
    console=None,
    set_modo_texto=None,
    get_modo_texto=None,
    pedir_parar=None,
):
    global _falar, _processar, _console, _set_modo_texto, _get_modo_texto, _pedir_parar
    _falar = falar_fn
    _processar = processar_fn
    _console = console
    _set_modo_texto = set_modo_texto
    _get_modo_texto = get_modo_texto
    _pedir_parar = pedir_parar


def _log(msg: str):
    if _console:
        try:
            _console.print(f"[dim]Bandeja:[/] {msg}")
            return
        except Exception:
            pass
    print(f"[Bandeja] {msg}")


def _carregar_config() -> dict:
    if CONFIG_FILE.exists():
        try:
            return json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {"iniciar_com_windows": False}


def _salvar_config(cfg: dict):
    MEMORY_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_FILE.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")


# ------------------------------------------------------------
# Início com o Windows
# ------------------------------------------------------------

def _startup_folder() -> Path:
    """Pasta Inicializar do usuário (Windows)."""
    appdata = os.environ.get("APPDATA")
    if appdata:
        return Path(appdata) / "Microsoft" / "Windows" / "Start Menu" / "Programs" / "Startup"
    return Path.home() / "AppData" / "Roaming" / "Microsoft" / "Windows" / "Start Menu" / "Programs" / "Startup"


def _atalho_startup_path() -> Path:
    return _startup_folder() / f"{STARTUP_NAME}.lnk"


def _vbs_startup_path() -> Path:
    return _startup_folder() / f"{STARTUP_NAME}.vbs"


def _script_jarvis() -> Path:
    return BASE_DIR / "jarvis.py"


def _python_exe() -> str:
    return sys.executable or "python"


def esta_no_inicio() -> bool:
    return _atalho_startup_path().exists() or _vbs_startup_path().exists()


def adicionar_ao_inicio() -> str:
    """Cria atalho/script na pasta Inicializar do Windows."""
    if not sys.platform.startswith("win"):
        return "Início automático com o Windows só está disponível no Windows."

    pasta = _startup_folder()
    try:
        pasta.mkdir(parents=True, exist_ok=True)
    except Exception as e:
        return f"Não consegui acessar a pasta Inicializar: {e}"

    jarvis_py = _script_jarvis()
    if not jarvis_py.exists():
        return f"Não encontrei jarvis.py em {jarvis_py}"

    python = _python_exe()
    # VBS inicia sem janela de console (mais limpo na bandeja)
    vbs = _vbs_startup_path()
    # Escapa aspas para VBS
    py_esc = str(python).replace('"', '""')
    script_esc = str(jarvis_py).replace('"', '""')
    work_esc = str(BASE_DIR).replace('"', '""')
    conteudo = f'''Set WshShell = CreateObject("WScript.Shell")
WshShell.CurrentDirectory = "{work_esc}"
WshShell.Run """{py_esc}"" ""{script_esc}""", 0, False
'''
    try:
        vbs.write_text(conteudo, encoding="utf-8")
    except Exception as e:
        return f"Erro ao criar script de inicialização: {e}"

    # Também tenta .lnk via PowerShell (mais “oficial”)
    lnk = _atalho_startup_path()
    try:
        ps = f'''
$ws = New-Object -ComObject WScript.Shell
$s = $ws.CreateShortcut("{str(lnk).replace('"', '`"')}")
$s.TargetPath = "{python.replace('"', '`"')}"
$s.Arguments = '"{jarvis_py}"'
$s.WorkingDirectory = "{str(BASE_DIR).replace('"', '`"')}"
$s.WindowStyle = 7
$s.Description = "Jarvis 1.0"
$s.Save()
'''
        subprocess.run(
            ["powershell", "-NoProfile", "-Command", ps],
            capture_output=True, timeout=15
        )
    except Exception:
        pass

    cfg = _carregar_config()
    cfg["iniciar_com_windows"] = True
    _salvar_config(cfg)
    return "Jarvis vai iniciar automaticamente com o Windows (pasta Inicializar)."


def remover_do_inicio() -> str:
    if not sys.platform.startswith("win"):
        return "Início automático só se aplica ao Windows."
    removidos = []
    for p in (_vbs_startup_path(), _atalho_startup_path()):
        try:
            if p.exists():
                p.unlink()
                removidos.append(p.name)
        except Exception as e:
            return f"Erro ao remover {p.name}: {e}"
    cfg = _carregar_config()
    cfg["iniciar_com_windows"] = False
    _salvar_config(cfg)
    if removidos:
        return "Removido do início do Windows: " + ", ".join(removidos)
    return "Jarvis não estava configurado para iniciar com o Windows."


def status_inicio() -> str:
    if not sys.platform.startswith("win"):
        return "Início com Windows: disponível apenas no Windows."
    if esta_no_inicio():
        return "Jarvis está configurado para iniciar com o Windows."
    return "Jarvis NÃO inicia automaticamente com o Windows. Diga: iniciar com o windows."


# ------------------------------------------------------------
# Ícone da bandeja
# ------------------------------------------------------------

def _criar_icone_imagem():
    """Gera ícone simples (círculo ciano) sem arquivo externo."""
    try:
        from PIL import Image, ImageDraw
    except ImportError:
        # pystray aceita imagem mínima
        from PIL import Image
        return Image.new("RGB", (64, 64), color=(11, 18, 32))

    size = 64
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    # fundo escuro circular
    draw.ellipse([2, 2, size - 3, size - 3], fill=(11, 18, 32, 255), outline=(94, 234, 212, 255), width=3)
    # orb
    draw.ellipse([16, 16, 48, 48], fill=(20, 184, 166, 255), outline=(94, 234, 212, 255), width=2)
    return img


def _acao_ouvir(icon=None, item=None):
    if _set_modo_texto:
        _set_modo_texto(False)
    if _falar:
        try:
            _falar("Modo escuta ativado. Estou ouvindo.")
        except Exception:
            pass
    _atualizar_titulo("Jarvis — ouvindo")


def _acao_modo_texto(icon=None, item=None):
    if _set_modo_texto:
        _set_modo_texto(True)
    if _falar:
        try:
            _falar("Modo escrita ativado.")
        except Exception:
            pass
    _atualizar_titulo("Jarvis — texto")


def _acao_status(icon=None, item=None):
    modo = "texto" if (_get_modo_texto and _get_modo_texto()) else "voz"
    inicio = "sim" if esta_no_inicio() else "não"
    msg = f"Status: online | Modo: {modo} | Início com Windows: {inicio}"
    _log(msg)
    if _falar:
        try:
            _falar(msg)
        except Exception:
            pass


def _acao_toggle_inicio(icon=None, item=None):
    if esta_no_inicio():
        resp = remover_do_inicio()
    else:
        resp = adicionar_ao_inicio()
    _log(resp)
    if _falar:
        try:
            _falar(resp)
        except Exception:
            pass
    # reconstrói menu para refletir estado
    if _icon:
        try:
            _icon.update_menu()
        except Exception:
            pass


def _acao_parar(icon=None, item=None):
    if _pedir_parar:
        try:
            _pedir_parar()
        except Exception:
            pass
    _log("Interrupção pedida.")


def _acao_sair(icon=None, item=None):
    global _tray_started
    _tray_started = False
    if _falar:
        try:
            _falar("Encerrando sistemas.")
        except Exception:
            pass
    try:
        if _icon:
            _icon.stop()
    except Exception:
        pass
    # encerra o processo principal
    threading.Thread(target=lambda: (os._exit(0)), daemon=True).start()


def _atualizar_titulo(texto: str):
    global _status_msg
    _status_msg = texto
    if _icon:
        try:
            _icon.title = texto
        except Exception:
            pass


def _montar_menu():
    import pystray
    from pystray import MenuItem as Item

    def label_inicio(item=None):
        return "Remover do início do Windows" if esta_no_inicio() else "Iniciar com o Windows"

    return pystray.Menu(
        Item("Jarvis 1.0", None, enabled=False),
        Item("Modo escuta (voz)", _acao_ouvir),
        Item("Modo escrita (texto)", _acao_modo_texto),
        Item("Parar fala / comando", _acao_parar),
        Item("Status", _acao_status),
        pystray.Menu.SEPARATOR,
        Item(label_inicio, _acao_toggle_inicio),
        pystray.Menu.SEPARATOR,
        Item("Sair", _acao_sair),
    )


def _tray_loop():
    global _icon, _tray_started
    try:
        import pystray
    except ImportError:
        _log("pystray não instalado. Rode: pip install pystray Pillow")
        _tray_started = False
        return

    if not sys.platform.startswith("win") and sys.platform != "darwin" and os.environ.get("DISPLAY") is None:
        # Linux headless sem display
        _log("Bandeja indisponível (sem interface gráfica).")
        _tray_started = False
        return

    image = _criar_icone_imagem()
    _icon = pystray.Icon(
        "jarvis",
        image,
        "Jarvis 1.0",
        menu=_montar_menu(),
    )
    _tray_started = True
    _log("Bandeja do sistema ativa.")
    try:
        _icon.run()
    except Exception as e:
        _log(f"Erro na bandeja: {e}")
    finally:
        _tray_started = False


def iniciar_bandeja() -> str:
    """Inicia o ícone da bandeja em thread separada."""
    global _tray_thread, _tray_started
    if _tray_started:
        return "Bandeja já está ativa."
    try:
        import pystray  # noqa: F401
    except ImportError:
        return "Para a bandeja, instale: pip install pystray Pillow"
    _tray_thread = threading.Thread(target=_tray_loop, daemon=True, name="jarvis-tray")
    _tray_thread.start()
    return "Bandeja do sistema iniciada. Ícone perto do relógio."


def bandeja_ativa() -> bool:
    return _tray_started


def processar_bandeja(texto: str):
    """Comandos de voz/texto para bandeja e início automático. None = não tratado."""
    if not texto:
        return None
    t = texto.lower().strip()

    if any(x in t for x in (
        "iniciar com o windows", "iniciar com windows", "começar com o windows",
        "comecar com o windows", "subir com o windows", "abrir com o windows",
        "adicionar ao inicio", "adicionar ao início", "iniciar no boot",
    )):
        return adicionar_ao_inicio()

    if any(x in t for x in (
        "não iniciar com o windows", "nao iniciar com o windows",
        "remover do inicio", "remover do início", "desativar inicio automatico",
        "desativar início automático", "parar de iniciar com o windows",
    )):
        return remover_do_inicio()

    if any(x in t for x in (
        "você inicia com o windows", "voce inicia com o windows",
        "inicia com o windows", "status do inicio", "status do início",
    )):
        return status_inicio()

    if any(x in t for x in (
        "abre a bandeja", "mostrar bandeja", "ícone da bandeja", "icone da bandeja",
        "bandeja do sistema", "system tray",
    )):
        return iniciar_bandeja()

    return None


def iniciar_servicos_bandeja(
    falar_fn=None,
    processar_fn=None,
    console=None,
    set_modo_texto=None,
    get_modo_texto=None,
    pedir_parar=None,
    tray=True,
):
    configurar(
        falar_fn=falar_fn,
        processar_fn=processar_fn,
        console=console,
        set_modo_texto=set_modo_texto,
        get_modo_texto=get_modo_texto,
        pedir_parar=pedir_parar,
    )
    if tray:
        try:
            iniciar_bandeja()
        except Exception as e:
            _log(f"Bandeja: {e}")
